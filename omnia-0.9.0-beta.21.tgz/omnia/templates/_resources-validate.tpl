{{/*
omnia.validateResources checks the values the operator's omnia-resources
release renders from (charts/omnia-resources). That chart renders inside the
operator, so a mistake caught there surfaces as an Event on the values
ConfigMap, after `helm install` has reported success. Caught here, it fails the
install and names the value to change.

Every check the resources templates would otherwise need lives here, once.
*/}}
{{- define "omnia.validateResources" -}}
{{- $rp := .Values.sessionRetention.defaultPolicy }}
{{- if and $rp.create $rp.coldArchive.enabled (not $rp.coldArchive.retentionDays) }}
{{- fail "sessionRetention.defaultPolicy.coldArchive.retentionDays is required when cold archive is enabled" }}
{{- end }}
{{- $sp := .Values.consolidation.systemPacks }}
{{- if and $sp.enabled (not $sp.safeDefault.providerRef.name) }}
{{- fail "consolidation.systemPacks.safeDefault.providerRef.name is required when consolidation.systemPacks.enabled — the safe-default-summarizer AgentRuntime names its Provider, and the CRD refuses an empty name." }}
{{- end }}
{{- $sb := .Values.sandbox }}
{{- if $sb.enabled }}
{{- if hasKey $sb "defaultClass" }}
{{- fail "sandbox.defaultClass has been renamed to sandbox.codegenClass: there is no default sandbox class any more — a ToolRegistry handler's `sandbox.class` names the class its sandboxes are built from, and the chart's codegen-sandbox registry names this one. Move name, resources and runtimeClassName under sandbox.codegenClass." }}
{{- end }}
{{- if not $sb.toolRegistry.namespace }}
{{- fail "sandbox.toolRegistry.namespace is required when sandbox.enabled — the namespace of the AgentRuntime this registry is for. A ToolRegistry an AgentRuntime cannot reference is not worth installing." }}
{{- end }}
{{- if not $sb.codegenClass.name }}
{{- fail "sandbox.codegenClass.name is required when sandbox.enabled — the codegen-sandbox ToolRegistry's handler names this class." }}
{{- end }}
{{- if not $sb.image }}
{{- fail "sandbox.image is required when sandbox.enabled — the ClusterSandboxClass has no other source for the image a claimed sandbox runs." }}
{{- end }}
{{- include "omnia.validateSandboxClass" (dict "c" $sb.codegenClass "path" "sandbox.codegenClass" "why" "the sandbox runs agent-directed code, and an unbounded pod can take the node down. The SandboxClass CRD rejects it too.") }}
{{- $pa := $sb.promptarenaClass }}
{{- if $pa.enabled }}
{{- if not $pa.name }}
{{- fail "sandbox.promptarenaClass.name is required when sandbox.promptarenaClass.enabled — SandboxClaims resolve their class by this name." }}
{{- end }}
{{- if not $pa.image.repository }}
{{- fail "sandbox.promptarenaClass.image.repository is required when sandbox.promptarenaClass.enabled — the ClusterSandboxClass has no other source for the image a claimed sandbox runs." }}
{{- end }}
{{- include "omnia.validateSandboxClass" (dict "c" $pa "path" "sandbox.promptarenaClass" "why" "the sandbox runs agent-directed code, and an unbounded pod can take the node down. The SandboxClass CRD rejects it too.") }}
{{- end }}
{{- $bc := $sb.browserClass }}
{{- if $bc.enabled }}
{{- if not $bc.name }}
{{- fail "sandbox.browserClass.name is required when sandbox.browserClass.enabled — SandboxClaims resolve their class by this name." }}
{{- end }}
{{- if not $bc.image.repository }}
{{- fail "sandbox.browserClass.image.repository is required when sandbox.browserClass.enabled." }}
{{- end }}
{{- include "omnia.validateSandboxClass" (dict "c" $bc "path" "sandbox.browserClass" "why" "the SandboxClass CRD rejects an untrusted class without them.") }}
{{- $ec := $bc.enrolment }}
{{- if $ec.enabled }}
{{- if not $ec.name }}
{{- fail "sandbox.browserClass.enrolment.name is required when the enrolment class is enabled: the operator's --browser-enrolment-class names it." }}
{{- end }}
{{- if not $ec.enrolmentArgs }}
{{- fail "sandbox.browserClass.enrolment.enrolmentArgs must be set: they start the bridge in interactive mode, and an enrolment class without them is refused." }}
{{- end }}
{{- if not $ec.view }}
{{- fail "sandbox.browserClass.enrolment.view is required: it names the port the dashboard's live view reaches." }}
{{- end }}
{{- if not $ec.ports }}
{{- fail "a sandbox class's values must set ports: the ToolRegistry handler addresses one by name, and a class without ports cannot be dialled" }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
omnia.validateSandboxClass: limits and ports for one class's values block.
Limits are mandatory because the CRD refuses an untrusted class without them,
and its admission error names a CEL expression rather than the value.
*/}}
{{- define "omnia.validateSandboxClass" -}}
{{- $lim := ((.c.resources).limits) | default dict }}
{{- if not (and (hasKey $lim "cpu") (hasKey $lim "memory")) }}
{{- fail (printf "%s.resources.limits must set both cpu and memory: %s" .path .why) }}
{{- end }}
{{- if not .c.ports }}
{{- fail "a sandbox class's values must set ports: the ToolRegistry handler addresses one by name, and a class without ports cannot be dialled" }}
{{- end }}
{{- end }}
