{{/*
Auth-mode guardrails — emits nothing but fails `helm template|install|upgrade`
when the deployment would silently run unauthenticated.

Rules:
  - dashboard.auth.mode MUST be explicitly set when dashboard.enabled=true.
    (The chart no longer has a safe default — you have to choose.)
  - Only oauth / builtin / proxy / anonymous are accepted.
  - mode=anonymous additionally requires dashboard.auth.allowAnonymous=true
    as an explicit acknowledgement. Anonymous mode disables authentication
    entirely and is intended for isolated development only.

Include this from every template that renders when dashboard.enabled=true
so the render aborts early on misconfiguration.
*/}}
{{- define "omnia.validateAuth" -}}
{{- if .Values.dashboard.enabled -}}
{{- $mode := required "dashboard.auth.mode must be set explicitly to one of: oauth, builtin, proxy, anonymous" .Values.dashboard.auth.mode -}}
{{- $validModes := list "oauth" "builtin" "proxy" "anonymous" -}}
{{- if not (has $mode $validModes) -}}
{{- fail (printf "dashboard.auth.mode=%q is not valid. Must be one of: oauth, builtin, proxy, anonymous" $mode) -}}
{{- end -}}
{{- if eq $mode "anonymous" -}}
{{- if not .Values.dashboard.auth.allowAnonymous -}}
{{- fail "dashboard.auth.mode=\"anonymous\" disables authentication entirely. Set dashboard.auth.allowAnonymous=true to acknowledge this is intentional. Anonymous mode is intended for isolated development only." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "omnia.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "omnia.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "omnia.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "omnia.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "omnia.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
control-plane: controller-manager
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "omnia.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "omnia.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Development mode — DERIVED, never configured directly.

Omnia has exactly three licensing states:

  Core      enterprise.enabled=false            enterprise features absent
  Dev mode  enterprise.enabled=true, no licence every feature on, banner on
  Licensed  enterprise.enabled=true + licence   every feature on, silent

"Enterprise installed but unlicensed" is not a fourth state — it IS dev mode.
So dev mode is not something you switch on; it is what you get when you ask for
Enterprise and supply no licence. There is no separate `devMode` value, because
two independent switches could disagree and only one of them was ever the truth.

Renders "true" or "" (falsey to `if`).

Escape hatch: a licence Secret created out of band — GitOps, sealed-secrets, an
operator applying `arena-license` by hand — appears in neither `license.key` nor
`license.existingSecret`, so such an install would derive dev mode and nag while
genuinely licensed. Set `license.externallyManaged: true` for that case.
*/}}
{{- define "omnia.devMode" -}}
{{- if and .Values.enterprise.enabled (not .Values.license.key) (not .Values.license.existingSecret) (not .Values.license.externallyManaged) -}}
true
{{- end -}}
{{- end }}

{{/*
Manager image
*/}}
{{- define "omnia.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag }}
{{- printf "%s:%s" .Values.image.repository $tag }}
{{- end }}

{{/*
Dashboard fullname
*/}}
{{- define "omnia.dashboard.fullname" -}}
{{- printf "%s-dashboard" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Dashboard labels
*/}}
{{- define "omnia.dashboard.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.dashboard.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Dashboard selector labels
*/}}
{{- define "omnia.dashboard.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-dashboard
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: dashboard
{{- end }}

{{/*
Dashboard image
*/}}
{{- define "omnia.dashboard.image" -}}
{{- $tag := default .Chart.AppVersion .Values.dashboard.image.tag }}
{{- printf "%s:%s" .Values.dashboard.image.repository $tag }}
{{- end }}

{{/*
Dashboard service account name.

The dashboard has its own ServiceAccount bound to a narrower ClusterRole
(omnia-dashboard-role, see templates/dashboard/clusterrole.yaml) so that a
dashboard compromise cannot escalate via the operator's manager ClusterRole.

Lookup order:
  1. .Values.dashboard.serviceAccount.name (explicit override)
  2. Computed: "<release>-dashboard"
  3. "default" when dashboard.serviceAccount.create=false and no name set.
*/}}
{{- define "omnia.dashboard.serviceAccountName" -}}
{{- if .Values.dashboard.serviceAccount.create }}
{{- default (include "omnia.dashboard.fullname" .) .Values.dashboard.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.dashboard.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
omnia.toolTest.bindAddress — operator tool-test API bind address.
Explicit operator.apiBindAddress wins; otherwise defaults to ":8083" when the
dashboard is enabled (its only consumer). Empty disables the API entirely.
*/}}
{{- define "omnia.toolTest.bindAddress" -}}
{{- if .Values.operator.apiBindAddress -}}
{{- .Values.operator.apiBindAddress -}}
{{- else if .Values.dashboard.enabled -}}
:8083
{{- end -}}
{{- end -}}

{{/*
omnia.contentApi.bindAddress — operator workspace-content API bind address.
The dashboard reads/writes workspace content through this authenticated operator
endpoint instead of mounting the NFS volume directly (#1462). Needs the
dashboard (it mints the identity JWT the operator verifies via JWKS); the
operator always mounts the workspace-content share root and has a content path.
Explicit workspaceContent.contentApi.bindAddress wins; defaults to ":8084".
Empty disables it.
*/}}
{{- define "omnia.contentApi.bindAddress" -}}
{{- $ca := .Values.workspaceContent.contentApi | default dict -}}
{{- if and .Values.dashboard.enabled $ca.enabled -}}
{{- $ca.bindAddress | default ":8084" -}}
{{- end -}}
{{- end -}}

{{/*
omnia.deployApi.bindAddress — operator deploy-intent API bind address.
The dashboard forwards DeployIntent bodies to this authenticated operator
endpoint, which verifies the dashboard-minted identity JWT (via
--mgmt-plane-jwks-url, already emitted unconditionally when the dashboard
is enabled) and applies the resulting spec. Explicit
workspaceContent.deployApi.bindAddress wins; defaults to ":8085". NOT ":8083"
-- omnia.toolTest.bindAddress (above) ALSO defaults to ":8083" whenever
dashboard.enabled is true (the chart's own default), so ":8083" here would
collide with the tool-test API on the same operator process and crash-loop
it on any default install. Empty disables the deploy API.
*/}}
{{- define "omnia.deployApi.bindAddress" -}}
{{- $da := .Values.workspaceContent.deployApi | default dict -}}
{{- if and .Values.dashboard.enabled $da.enabled -}}
{{- $da.bindAddress | default ":8085" -}}
{{- end -}}
{{- end -}}

{{/*
Compaction image
*/}}
{{- define "omnia.compaction.image" -}}
{{- $tag := default .Chart.AppVersion .Values.sessionRetention.compaction.image.tag }}
{{- printf "%s:%s" .Values.sessionRetention.compaction.image.repository $tag }}
{{- end }}

{{/*
PromptKit LSP image.

Every image reference belongs in one helper reading one values path. The LSP's
was inlined in its Deployment with a `default "ghcr.io/..."` fallback that could
never fire — values.yaml already sets the repository — so the literal was dead
code shadowing the configured value, and a registry rewrite would have missed it.
*/}}
{{- define "omnia.promptkitLsp.image" -}}
{{- $lsp := .Values.enterprise.promptkitLsp }}
{{- $tag := default .Chart.AppVersion $lsp.image.tag }}
{{- printf "%s:%s" $lsp.image.repository $tag }}
{{- end }}

{{/*
Image used by the chart's `helm test` hooks.

Parameterised for the same reason: a hardcoded `busybox:1.36` is unreachable in
an air-gapped install and invisible to any tooling that rewrites registries.
*/}}
{{- define "omnia.test.image" -}}
{{- printf "%s:%s" .Values.tests.image.repository .Values.tests.image.tag }}
{{- end }}

{{/*
Session API image.

Only the IMAGE, deliberately. session-api is not a chart-owned workload: the
operator creates one per service group, so its name, labels and selector are
the operator's business. The chart's job is to tell the operator which image to
use. The fullname/labels/selectorLabels helpers that used to sit here were left
behind by that move and were included by nothing.
*/}}
{{- define "omnia.sessionApi.image" -}}
{{- $tag := default .Chart.AppVersion .Values.workspaceServices.sessionApi.image.tag }}
{{- printf "%s:%s" .Values.workspaceServices.sessionApi.image.repository $tag }}
{{- end }}

{{/*
Memory API image. Operator-managed, same as session-api above.
*/}}
{{- define "omnia.memoryApi.image" -}}
{{- $tag := default .Chart.AppVersion .Values.workspaceServices.memoryApi.image.tag }}
{{- printf "%s:%s" .Values.workspaceServices.memoryApi.image.repository $tag }}
{{- end }}

{{/*
Workspace Eval Worker image (operator-managed per-service-group worker)
*/}}
{{- define "omnia.workspaceEvalWorker.image" -}}
{{- $tag := default .Chart.AppVersion .Values.workspaceServices.evalWorker.image.tag }}
{{- printf "%s:%s" .Values.workspaceServices.evalWorker.image.repository $tag }}
{{- end }}

{{/*
Privacy API image (operator-managed per-workspace service)
*/}}
{{- define "omnia.privacyApi.image" -}}
{{- $tag := default .Chart.AppVersion .Values.workspaceServices.privacyApi.image.tag }}
{{- printf "%s:%s" .Values.workspaceServices.privacyApi.image.repository $tag }}
{{- end }}

{{/*
Doctor fullname
*/}}
{{- define "omnia.doctor.fullname" -}}
{{- printf "%s-doctor" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Doctor labels
*/}}
{{- define "omnia.doctor.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.doctor.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Doctor selector labels
*/}}
{{- define "omnia.doctor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-doctor
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: doctor
{{- end }}

{{/*
Doctor image
*/}}
{{- define "omnia.doctor.image" -}}
{{- $tag := default .Chart.AppVersion .Values.doctor.image.tag }}
{{- printf "%s:%s" .Values.doctor.image.repository $tag }}
{{- end }}


{{/*
Walk a dotted path into .Values and return the resolved sub-value, or
an empty dict if any segment is missing. Internal helper.
*/}}
{{- define "omnia.redis._lookupConsumer" -}}
{{- $ctx := .ctx -}}
{{- $path := .consumer -}}
{{- $node := $ctx.Values -}}
{{- if $path -}}
  {{- range $part := splitList "." $path -}}
    {{- if and (kindIs "map" $node) (hasKey $node $part) -}}
      {{- $node = index $node $part -}}
    {{- else -}}
      {{- $node = dict -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $node -}}
{{- end }}

{{/*
Resolve the existingSecret reference for a given consumer's Redis URL.

Args (dict):
  ctx      - the root context ($)
  consumer - dotted path to the per-consumer Redis block.

Returns the resolved {name, key} dict from consumer.existingSecret
(preferred) or redis.default.existingSecret (fallback). Returns an
empty dict when neither has one. Internal helper for the public
omnia.redis.* family.
*/}}
{{- define "omnia.redis._existingSecret" -}}
{{- $consumer := fromYaml (include "omnia.redis._lookupConsumer" .) -}}
{{- $default := .ctx.Values.redis.default | default dict -}}
{{- $secret := dict -}}
{{- if and (kindIs "map" $consumer) (kindIs "map" $consumer.existingSecret) (default "" $consumer.existingSecret.name) (default "" $consumer.existingSecret.key) -}}
  {{- $secret = $consumer.existingSecret -}}
{{- else if and (kindIs "map" $default.existingSecret) (default "" $default.existingSecret.name) (default "" $default.existingSecret.key) -}}
  {{- $secret = $default.existingSecret -}}
{{- end -}}
{{- toYaml $secret -}}
{{- end }}

{{/*
Resolve the Redis URL for a given consumer.

Args (dict):
  ctx      - the root context ($)
  consumer - dotted path to the per-consumer Redis block, e.g.
             "dashboard.session.redis"
             "workspaceServices.memoryApi.cache.redis"
             "enterprise.arena.queue.redis"

Resolution order — first non-empty wins:
  1. <consumer>.existingSecret    → returns ""; caller uses
     omnia.redis.urlEnv to emit a secretKeyRef-sourced env entry.
  2. <consumer>.url               → literal URL.
  3. <consumer>.host              → decomposed; synthesise plaintext URL.
  4. redis.default.existingSecret → returns "" (same as 1).
  5. redis.default.url            → literal URL.
  6. redis.default.host           → decomposed; synthesise plaintext URL.
  7. ""                           → consumer disabled.

There is no in-chart Redis arm. charts/omnia-dev runs one for development and
values-dev.yaml points redis.default.host at it, so a dev install resolves
through form 6 like any other.

`omnia.redis.url` returns the literal URL string for forms 2, 3, 5, 6
or empty string for forms 1, 4, 7. To detect the existingSecret form
and emit the correct env entry, use `omnia.redis.hasSecret` and
`omnia.redis.urlEnv` (paired helper).
*/}}
{{- define "omnia.redis.url" -}}
{{- $secret := fromYaml (include "omnia.redis._existingSecret" .) -}}
{{- if and (kindIs "map" $secret) $secret.name -}}
{{- /* secret form — caller renders env via omnia.redis.urlEnv */ -}}
{{- else -}}
{{- $consumer := fromYaml (include "omnia.redis._lookupConsumer" .) -}}
{{- $default := .ctx.Values.redis.default | default dict -}}
{{- if and (kindIs "map" $consumer) $consumer.url -}}
{{- $consumer.url -}}
{{- else if and (kindIs "map" $consumer) $consumer.host -}}
{{- include "omnia.redis.synthesise" $consumer -}}
{{- else if $default.url -}}
{{- $default.url -}}
{{- else if $default.host -}}
{{- include "omnia.redis.synthesise" $default -}}
{{- /*
No in-chart fallback. There used to be one more arm here, synthesising a URL
for a Redis the chart deployed itself — which meant the parent had to know a
resource name it no longer owns. charts/omnia-dev runs that Redis now, and
values-dev.yaml sets `redis.default.host` to its Service, so a dev install
resolves through `$default.host` above like any other install.
*/ -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Returns "true" when the consumer's resolved URL comes from an
existingSecret (rather than a literal URL or decomposed form);
otherwise returns "". Use to branch in templates between literal-value
and secretKeyRef-sourced EnvVar emission.
*/}}
{{- define "omnia.redis.hasSecret" -}}
{{- $secret := fromYaml (include "omnia.redis._existingSecret" .) -}}
{{- if and (kindIs "map" $secret) $secret.name -}}
true
{{- end -}}
{{- end }}

{{/*
Emit a single EnvVar entry carrying the resolved Redis URL.

Args (dict):
  ctx      - the root context ($)
  consumer - dotted path to the per-consumer Redis block.
  envName  - name of the env var to emit, e.g. "OMNIA_SESSION_REDIS_URL".

Produces nothing when the consumer's URL resolves empty (consumer
disabled). Use the alongside `omnia.validate*` helpers to fail render
when an empty URL would silently break the consumer.

Output forms:
  Literal/decomposed/subchart →
    - name: <envName>
      value: "<resolved URL>"

  existingSecret →
    - name: <envName>
      valueFrom:
        secretKeyRef:
          name: "<secret name>"
          key:  "<secret key>"

Pod templates use this in their env: list:

  env:
    {{- include "omnia.redis.urlEnv" (dict "ctx" . "consumer" "..." "envName" "...") | nindent 12 }}
*/}}
{{- define "omnia.redis.urlEnv" -}}
{{- $secret := fromYaml (include "omnia.redis._existingSecret" .) -}}
{{- if and (kindIs "map" $secret) $secret.name -}}
- name: {{ .envName }}
  valueFrom:
    secretKeyRef:
      name: {{ $secret.name | quote }}
      key: {{ $secret.key | quote }}
{{- else -}}
{{- $url := include "omnia.redis.url" . -}}
{{- if $url -}}
- name: {{ .envName }}
  value: {{ $url | quote }}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Synthesise a plaintext Redis URL from a decomposed config block.

Block shape:
  host: required
  port: default 6379
  db:   default 0
  user: default "" (Redis ACL default user)
  tls.caExistingSecret: ignored here (CA is mounted as a file by
    consumer templates; the URL just uses redis:// vs rediss://
    based on the scheme implied by tls).

Output: "redis://[user@]host:port/db".

The decomposed form intentionally cannot synthesise auth (no password
field). Callers wanting auth use the `existingSecret` form instead.
*/}}
{{- define "omnia.redis.synthesise" -}}
{{- $port := default 6379 .port -}}
{{- $db := default 0 .db -}}
{{- $user := default "" .user -}}
{{- if $user -}}
{{- printf "redis://%s@%s:%v/%v" $user .host $port $db -}}
{{- else -}}
{{- printf "redis://%s:%v/%v" .host $port $db -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: dashboard.replicaCount > 1 with no resolved session
Redis means per-pod in-memory sessions. Users get logged out the moment
their request hits a different replica. Fail render rather than ship a
silently broken multi-replica deployment.

Include this from every template that renders when dashboard.enabled=true.
*/}}
{{- define "omnia.validateSession" -}}
{{- if .Values.dashboard.enabled -}}
{{- $replicas := int (default 1 .Values.dashboard.replicaCount) -}}
{{- if gt $replicas 1 -}}
{{- $args := dict "ctx" . "consumer" "dashboard.session.redis" -}}
{{- $sessionURL := include "omnia.redis.url" $args -}}
{{- $hasSecret := include "omnia.redis.hasSecret" $args -}}
{{- if and (not $sessionURL) (not $hasSecret) -}}
{{- fail "dashboard.replicaCount > 1 requires a resolvable Redis session store. Set redis.default or dashboard.session.redis (dev: enable charts/omnia-dev and point redis.default.host at it, as values-dev.yaml does), or scale to dashboard.replicaCount=1." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: a multi-replica dashboard on the builtin-auth SQLite
store is broken. SQLite is single-writer — its PVC is RWO (one node only)
and concurrent writers corrupt the file even on a shared mount, so the
auth store cannot be shared across replicas. Scaling out the builtin auth
store requires a real shared DB (postgresql). Fail render rather than ship
a deployment that wedges on multi-node or silently corrupts the user DB.

Include this from every template that renders when dashboard.enabled=true.
*/}}
{{- define "omnia.validateBuiltinStore" -}}
{{- if .Values.dashboard.enabled -}}
{{- $replicas := int (default 1 .Values.dashboard.replicaCount) -}}
{{- $authMode := default "" .Values.dashboard.auth.mode -}}
{{- $storeType := default "" .Values.dashboard.builtin.storeType -}}
{{- if and (gt $replicas 1) (eq $authMode "builtin") (eq $storeType "sqlite") -}}
{{- fail "dashboard.replicaCount > 1 with auth.mode=builtin requires builtin.storeType=postgresql — SQLite is single-writer and cannot be shared across replicas. Set dashboard.builtin.storeType=postgresql (with builtin.postgresUrl or builtin.existingPostgresSecret) or scale to dashboard.replicaCount=1." -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: dashboard.apiKeys.store=postgres requires a Postgres URL
(inline or via existingSecret), and store=file requires a keysSecret.
Include this from every template that renders when dashboard.enabled=true.
*/}}
{{- define "omnia.validateApiKeyStore" -}}
{{- if .Values.dashboard.enabled -}}
{{- $ak := .Values.dashboard.apiKeys -}}
{{- if eq (default "memory" $ak.store) "postgres" -}}
{{- $hasUrl := or $ak.postgresUrl $ak.existingPostgresSecret -}}
{{- $builtin := .Values.dashboard.builtin -}}
{{- $hasBuiltin := and (eq .Values.dashboard.auth.mode "builtin") (or $builtin.postgresUrl $builtin.existingPostgresSecret) -}}
{{- if not (or $hasUrl $hasBuiltin) -}}
{{- fail "dashboard.apiKeys.store=postgres requires dashboard.apiKeys.postgresUrl or dashboard.apiKeys.existingPostgresSecret (or builtin postgres config to fall back to)." -}}
{{- end -}}
{{- end -}}
{{- if eq (default "memory" $ak.store) "file" -}}
{{- if not $ak.keysSecret -}}
{{- fail "dashboard.apiKeys.store=file requires dashboard.apiKeys.keysSecret (the Secret holding keys.json)." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Effective api-key store. A wired postgres secret/URL with the store left at the
"memory" default is almost always a misconfig: in-memory keys are lost on every
dashboard restart, silently breaking saved credentials (e.g. deploy-profile
tokens). Promote memory -> postgres when a postgres secret/URL is configured so
a durable backend isn't silently ignored (#1582). Explicit store=file/postgres
is honoured as-is. Used by both the dashboard configmap (OMNIA_AUTH_API_KEYS_STORE)
and deployment (postgres URL env) so they never disagree.
*/}}
{{- define "omnia.dashboard.apiKeyStore" -}}
{{- $ak := .Values.dashboard.apiKeys -}}
{{- $store := default "memory" $ak.store -}}
{{- if and (eq $store "memory") (or $ak.postgresUrl $ak.existingPostgresSecret) -}}
{{- $store = "postgres" -}}
{{- end -}}
{{- $store -}}
{{- end }}

{{/*
Render-time guard: enterprise Arena queue requires durable Redis when
type=redis (which is the default). The in-memory queue mode is only
useful in dev / E2E; production Arena needs jobs to survive controller
restarts.
*/}}
{{- define "omnia.validateArenaQueue" -}}
{{- if and .Values.enterprise.enabled (eq (default "redis" .Values.enterprise.arena.queue.type) "redis") -}}
{{- $args := dict "ctx" . "consumer" "enterprise.arena.queue.redis" -}}
{{- $arenaURL := include "omnia.redis.url" $args -}}
{{- $hasSecret := include "omnia.redis.hasSecret" $args -}}
{{- if and (not $arenaURL) (not $hasSecret) -}}
{{- fail "enterprise.arena.queue.type=redis requires a resolvable Redis URL. Set redis.default or enterprise.arena.queue.redis (dev: enable charts/omnia-dev and point redis.default.host at it, as values-dev-enterprise.yaml does), or set enterprise.arena.queue.type=memory (dev only)." -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: the CRDs are a SEPARATE release (charts/omnia-crds).

Both available primitives fail the same way off-cluster — `lookup` returns empty
under `helm template` and `--dry-run`, and .Capabilities.APIVersions holds only
the built-in list — so a naive check cannot tell "CRD absent" from "no cluster to
ask", and would fire on every render including the GCP marketplace deployer's.
kube-system is the liveness probe: it exists on every cluster and nowhere else.

The assertion is >=, not ==. CRDs must always roll forward ahead of the app, so a
staggered upgrade (crds first, app second) is the CORRECT order and equality
would reject it.

An absent chart-version annotation FAILS render — it does not skip the check.
The design this superseded treated it as a grace period lasting "until the CRD
chart's first upgrade", but that upgrade never arrives for an operator who runs
`helm upgrade omnia` against CRDs adopted from a pre-omnia-crds install and
never once installs the omnia-crds release: `lookup` finds the kinds (adopted
CRDs keep serving), the annotation is absent so the old code skipped the
version check, and the upgrade silently succeeds — new operator code running
forever against beta.17-shaped CRD schemas, on a cluster that will never
upgrade again because nothing ever told it to. Failing here instead names the
two recovery commands below, and every workflow that installs this chart
against a live cluster installs omnia-crds from the chart first (which stamps
the annotation on every kind), so this is not a new liveness dependency for
CI — only for a genuinely pre-split cluster, which is exactly the case this
must catch.
*/}}
{{- define "omnia.validateCrds" -}}
{{- if .Values.crdPreflight.enabled -}}
{{- $live := lookup "v1" "Namespace" "" "kube-system" -}}
{{- if $live -}}
{{- if not (.Capabilities.APIVersions.Has "omnia.altairalabs.ai/v1alpha1/AgentRuntime") -}}
{{- fail (printf "Omnia CRDs are not installed. They ship as their own release since 0.9.0-beta.18:\n\n  helm install omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s\n\nUpgrading an install that predates that chart? The CRDs already in your cluster carry no Helm ownership metadata, so run hack/adopt-crds.sh --release-namespace %s first.\n\nIf the identity running this install cannot get namespaces, set crdPreflight.enabled=false." .Chart.Version .Release.Namespace .Release.Namespace) -}}
{{- end -}}
{{- if and .Values.enterprise.enabled (not (.Capabilities.APIVersions.Has "omnia.altairalabs.ai/v1alpha1/ArenaRun")) -}}
{{- fail (printf "enterprise.enabled=true, but omnia-crds was installed with enterprise.enabled=false, so the enterprise kinds are missing (Arena, ToolPolicy, RolloutAnalysis, SessionPrivacyPolicy, PromptPackSource). Flipping enterprise.enabled here does not create them — they are a separate release's business:\n\n  helm upgrade omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s --set enterprise.enabled=true\n" .Chart.Version .Release.Namespace) -}}
{{- end -}}
{{- $crd := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "agentruntimes.omnia.altairalabs.ai" -}}
{{- $v := "" -}}
{{- if $crd -}}
{{- $v = dig "metadata" "annotations" "omnia.altairalabs.ai/chart-version" "" $crd -}}
{{- end -}}
{{- if not $v -}}
{{- fail (printf "Omnia CRDs are installed, but carry no omnia.altairalabs.ai/chart-version annotation — these kinds exist but no omnia-crds RELEASE owns them, which means this is a pre-split cluster (CRDs from the old crds/ mechanism, or adopted ownership metadata without ever installing the chart). Adopt them, then install the release:\n\n  hack/adopt-crds.sh --context <ctx> --release-namespace %s\n  helm install omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s\n\nIf the identity running this install cannot get namespaces, set crdPreflight.enabled=false." .Release.Namespace .Chart.Version .Release.Namespace) -}}
{{- end -}}
{{- if not (semverCompare (printf ">=%s" .Chart.Version) $v) -}}
{{- fail (printf "omnia-crds is at %s, older than this chart at %s. CRDs roll forward FIRST:\n\n  helm upgrade omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s\n" $v .Chart.Version .Chart.Version .Release.Namespace) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Resolve OTLP tracing endpoint for runtime/facade containers.
Priority:
1. .Values.tracing.endpoint (explicit override)
2. Alloy service (when alloy.enabled=true)
3. Tempo service (when tempo.enabled=true)
Returns empty string when no endpoint can be resolved.
*/}}
{{- define "omnia.tracing.endpoint" -}}
{{- if .Values.tracing.endpoint -}}
{{- .Values.tracing.endpoint -}}
{{- else if .Values.alloy.enabled -}}
{{- printf "%s-alloy:4317" .Release.Name -}}
{{- else if .Values.tempo.enabled -}}
{{- printf "%s-tempo:4317" .Release.Name -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}
