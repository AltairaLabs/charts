{{/*
omnia.sandboxClassBackend renders the part of a SandboxClass spec that says how
its image runs: args, env, ports, readiness, filesystem and connections, from
one class's values block. The operator knows nothing about any image; each
shipped class's shape is configuration, and this is where the chart writes it.
*/}}
{{- define "omnia.sandboxClassBackend" -}}
{{- $c := . -}}
{{- if not $c.ports }}
{{- fail "a sandbox class's values must set ports: the ToolRegistry handler addresses one by name, and a class without ports cannot be dialled" }}
{{- end }}
{{- with $c.args }}
args:
{{ toYaml . | indent 2 }}
{{- end }}
{{- with $c.env }}
env:
{{ toYaml . | indent 2 }}
{{- end }}
ports:
{{ toYaml $c.ports | indent 2 }}
{{- with $c.readiness }}
readiness:
{{ toYaml . | indent 2 }}
{{- end }}
{{- with $c.filesystem }}
filesystem:
{{ toYaml . | indent 2 }}
{{- end }}
{{- with $c.connections }}
connections:
{{ toYaml . | indent 2 }}
{{- end }}
{{- end }}
