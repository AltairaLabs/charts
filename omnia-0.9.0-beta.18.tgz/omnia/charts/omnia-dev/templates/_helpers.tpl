{{/*
Names and labels for omnia-dev.

These resources keep the names they had when these templates lived in the
parent chart: `<release>-redis-master`, `<release>-postgres`,
`<release>-nfs-server`. That is a deliberate constraint, not laziness.

Moving the templates renamed nothing a user configures, but it would have
renamed the OBJECTS — and 97 places outside this chart hardcode those object
names: the Go E2E suites, scripts/setup-arena-e2e.sh, the Tiltfile's resource
graph, charts/omnia-dev-content. Those names are the real contract, so the subchart
matches the parent's naming rather than inventing `<release>-dev-*`.

The one thing a subchart genuinely cannot do is read the parent's
`nameOverride`/`fullnameOverride` — they are not global. An install that sets
either gets subchart resources named from the release alone. That is a narrow
gap, it is visible (the Services simply carry the release-derived name), and it
is far narrower than renaming every object in the chart.
*/}}

{{- define "omnia-dev.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "omnia-dev.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else if contains "omnia" .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-omnia" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "omnia-dev.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "omnia-dev.labels" -}}
helm.sh/chart: {{ include "omnia-dev.chart" . }}
{{ include "omnia-dev.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "omnia-dev.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia-dev.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
The in-cluster service hostnames, in one place so the values files that point
the parent at them can be checked against a single definition rather than a
remembered string.
*/}}
{{- define "omnia-dev.postgres.host" -}}
{{- printf "%s-postgres.%s.svc.cluster.local" (include "omnia-dev.fullname" .) .Release.Namespace }}
{{- end }}

{{- define "omnia-dev.redis.host" -}}
{{- printf "%s-redis-master.%s.svc.cluster.local" (include "omnia-dev.fullname" .) .Release.Namespace }}
{{- end }}

{{- define "omnia-dev.nfs.host" -}}
{{- printf "%s-nfs-server.%s.svc.cluster.local" (include "omnia-dev.fullname" .) .Release.Namespace }}
{{- end }}
