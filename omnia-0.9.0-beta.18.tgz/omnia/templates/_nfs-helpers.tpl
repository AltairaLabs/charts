{{/*
The NFS server the CSI driver mounts from.

One source, not two. The chart used to branch between an in-cluster server it
deployed itself and an external one; the in-cluster server now lives in
charts/omnia-dev, and a dev install points `nfs.external.server` at its Service
exactly as a production install points at a filer or EFS mount target. See
charts/omnia/values-dev-nfs.yaml.

CSI driver pods resolve cluster DNS, so a Service DNS name is a valid value here.
*/}}
{{- define "omnia.nfsServer" -}}
{{ .Values.nfs.external.server }}
{{- end -}}

{{/*
The NFS export path. `/` for an NFSv4 pseudo-root export (which is what the dev
server publishes, with fsid=0); a real path for a filer.
*/}}
{{- define "omnia.nfsPath" -}}
{{ .Values.nfs.external.path }}
{{- end -}}

{{/*
Get the NFS storage class name.
Returns the configured storage class name for NFS-backed PVCs.
*/}}
{{- define "omnia.nfsStorageClass" -}}
{{ .Values.nfs.csiDriver.storageClass.name | default "omnia-nfs" }}
{{- end -}}
