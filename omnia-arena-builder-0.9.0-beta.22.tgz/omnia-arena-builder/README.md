# omnia-arena-builder

The Arena builder agent as an Omnia module (`blueprint` tier). The builder is a
dashboard-only agent that agrees a brief with you and then writes a PromptArena
project inside a sandbox bound to that project.

Install it once per workspace namespace. Full guide:
[Install the Arena builder](https://omnia.altairalabs.ai/docs/how-to/evaluation/install-the-builder/).

## Install

```bash
helm install arena-builder oci://ghcr.io/altairalabs/charts/omnia-arena-builder \
  --version <omnia-version> \
  --namespace <workspace-namespace> \
  --set provider.name=<provider>
```

Every Omnia release publishes this chart at the release's version, to
`oci://ghcr.io/altairalabs/charts` and to `https://charts.altairalabs.ai`.

The sandbox image is built from
[`Dockerfile.promptarena-sandbox`](../../Dockerfile.promptarena-sandbox) in this repo
and published as `ghcr.io/altairalabs/omnia-promptarena-sandbox` with every
Omnia release. The chart pins it by digest. The chart in this repo has no
default for the digest; the release stamps the published chart with the digest
of the image it just pushed, so nothing pulls by tag and a published chart
installs without one.

## Prerequisites

- Omnia `>=0.9.0` with Enterprise enabled (Arena).
- Workspace content storage in the namespace: the PVC
  `workspace-<namespace>-content`. The sandbox mounts the project from it.
- A `Provider` in the namespace.

## What it renders

All into the release namespace, all named `agent.name` (default
`arena-builder`), all labelled `omnia.altairalabs.ai/role: arena-builder`.
Everything except the ToolPolicy is also labelled
`omnia.altairalabs.ai/hidden: "true"`; the permit-all policy stays visible to
admins.

| Kind | What |
|---|---|
| `SandboxClass` | omnia-promptarena-sandbox by digest; `mounts: [{role: project, access: ReadWrite}]`; no egress; never `trusted` |
| `ToolRegistry` | `sandbox` (mcp, `sandbox: {class: SandboxClass/<agent.name>, allocation: lazy}`, allowlist = `allowedTools`), `ask-questions` and `update-spec` (client tools `ask_questions` / `update_spec`; the dashboard maps them onto Atlas `AtlasInputRequest` and `AtlasBrief`), and, when `discovery.enabled`, `catalog` (`type: platform`, `platform.service: discovery`), and, when `arena.enabled`, `arena` (`type: platform`, `platform.service: arena`) |
| `ConfigMap` + `PromptPack` | `pack.json` (id `arena-builder`, prompt `default`), system prompt from `files/system-prompt.md`, top-level `tools` map from `files/sandbox-tools.json` |
| `AgentRuntime` | `mode: agent`; one websocket facade, `dataPlane: false`, `managementPlane: true`; `sandbox: {enabled, idleTimeout, maxConcurrent}`; `providers[default]` = `provider.name` |
| `ToolPolicy` | permits every tool in the registry (the broker is default-deny); `toolPolicy.enabled: false` to manage your own |

Module invariants: no Provider, Workspace, Secret, PersistentVolumeClaim or
ClusterSandboxClass; no `trusted: true`; image pinned by digest; required
values (`provider.name`, `sandbox.image.digest`) have no default in this repo (a release stamps the digest into the published chart).

## Values

| Key | Default | |
|---|---|---|
| `provider.name` | required | Existing Provider in the namespace |
| `agent.name` | `arena-builder` | Name of every rendered object |
| `agent.clientToolTimeout` | `15m` | Facade wait for a client tool answer per turn; empty = facade default (60s) |
| `agent.systemPrompt` | `""` | Replaces `files/system-prompt.md`; must not contain `{{` (template_engine) |
| `agent.annotations` | `{}` | Extra AgentRuntime annotations (e.g. the runtime's `mock-provider` / `mock-config-path` in a test cluster) |
| `agent.runtime` | `{}` | Passed through as `spec.runtime`: `volumes`, `volumeMounts`, `extraEnv`, `resources`, ... |
| `sandbox.image.repository` | `ghcr.io/altairalabs/omnia-promptarena-sandbox` | Built from `Dockerfile.promptarena-sandbox` |
| `sandbox.image.digest` | required here; set in the published chart | `sha256:<64 hex>`; each release stamps the digest of its image |
| `sandbox.image.tag` | `""` | Display only (`repo:tag@digest`), e.g. the Omnia version |
| `sandbox.resources` | 100m/128Mi requests, 2/2Gi limits | cpu and memory limits required. The memory request is the per-session reservation on a node: a sandbox measured ~5MiB idle, 17-36MiB at peak after validate, compile and an offline run, and up to ~98MiB for the first on a cold node |
| `sandbox.runtimeClassName` | `""` | |
| `sandbox.nodeSelector` | `{}` | |
| `sandbox.tolerations` | `[]` | |
| `sandbox.idleTimeout` | `30m` | |
| `sandbox.mountReleaseGrace` | `5m` | How long a closed builder session keeps its sandbox before it is released; a return after it gets a new sandbox on the same files |
| `sandbox.maxConcurrent` | `4` | Builder sandboxes running at once across every user of the workspace; a first tool call past it queues until a slot frees. See [Sizing the sandbox ceiling](#sizing-the-sandbox-ceiling) |
| `toolCallTimeout` | `5m` | Sandbox tool call timeout (cold start budget) |
| `allowedTools` | Read, Write, Edit, Bash | Copied from the main chart's `sandbox.allowedTools`; each needs an entry in `files/sandbox-tools.json` |
| `toolPolicy.enabled` | `true` | |
| `discovery.enabled` | `true` | Adds a `type: platform` ToolRegistry handler (`platform.service: discovery`) and its three tools — `catalog_overview`, `catalog_search`, `catalog_get` — so the builder can search this workspace's providers, tools, skills and agents before writing `deploy.config` or binding tools for a scenario, instead of guessing names. Needs the operator running with `--platform-api-url`; without it the controller skips the handler and the builder works exactly as it did before this value existed |
| `arena.enabled` | `true` | Adds a `type: platform` ToolRegistry handler (`platform.service: arena`) and its three tools — `arena_check_project`, `arena_start_run`, `arena_get_run` — so the builder can check the project mounted in its sandbox, start a real run of its pushed commit on the workspace's own Providers (the builder commits in its sandbox and never pushes; `arena_start_run` answers `409` "commit and push first" until the person syncs), and read the result, without any provider credential entering the sandbox. Needs the operator running with `--platform-api-url`; without it the controller skips the handler and the builder works exactly as it did before this value existed |

## Sizing the sandbox ceiling

Every builder session holds one sandbox from its first tool call. When the
conversation ends (the page closes its socket), the sandbox is released after
`sandbox.mountReleaseGrace` (5m) unless the person comes back first; it also
goes once it has been idle for `sandbox.idleTimeout`. A person who returns
after the release gets a new sandbox on the same project files: the project
lives on the workspace volume, so only the old pod's caches are lost, and the
cost is a cold start. The slots a workspace needs are therefore about

```
maxConcurrent ≈ users active at once + users who left within the last mountReleaseGrace
```

A user who arrives when every slot is taken waits on their first tool call
(the claim reports `Queued` / `CeilingReached`) until one frees, and the call
fails if none frees within `toolCallTimeout`. A conversation that ends while
its claim is still waiting gives the claim up rather than taking a slot later;
the next message declares the project again and queues afresh.

Each sandbox reserves `sandbox.resources.requests` on a node, so the ceiling
is also a capacity commitment: `maxConcurrent × requests.memory` must fit
beside the workspace's other pods. A sandbox the scheduler cannot place
reports `Pending` / `Unschedulable` on its claim, with the scheduler's message,
and the builder's status pill shows it.

## Sandbox tool schemas

The runtime never dials a sandbox at startup, so the sandbox tools'
descriptions and input schemas come from the pack. `files/sandbox-tools.json`
is the image's own MCP `tools/list`, and the pack's top-level `tools` map is
built from it, filtered by `allowedTools`. When the image changes, regenerate
it (needs docker):

```bash
python3 hack/gen-arena-builder-sandbox-tools.py sha256:<new digest>
# or from a local build of Dockerfile.promptarena-sandbox:
make docker-build-promptarena-sandbox
python3 hack/gen-arena-builder-sandbox-tools.py omnia-promptarena-sandbox:dev
```

## Local development (Tilt)

`ENABLE_ENTERPRISE=true ENABLE_ARENA_BUILDER=true tilt up` builds
`Dockerfile.promptarena-sandbox` and installs this chart into `omnia-demo` with
`provider.name` from `ARENA_BUILDER_PROVIDER` (default `arena-builder-haiku`).
The chart still renders a digest-pinned reference (a placeholder digest);
Tilt's `k8s_kind('^SandboxClass$', image_json_path='{.spec.image}')` replaces
the whole reference with its local build, so there is no digest-free override
in the chart. It is the same build `ENABLE_SANDBOXES=true` uses for the chart's
promptarena class, and a rebuild deletes the running sandbox pods so they come
back on it.

## Client tool schemas are portable

The builder runs on whichever Provider the workspace has, in that provider's
default mode, including strict tool use where the provider defaults to it. So
the `ask_questions` and `update_spec` schemas stay in the portable subset that
`pkg/toolschema` checks: every property required, `additionalProperties:
false`, one concrete type per node, no bounds, formats or combinators, and at
most three objects deep. `update_spec` carries the brief as a JSON string for
that reason; the dashboard parses and validates it and fails the call with
the reason when it does not fit, which the model is told and the runtime logs.

## Test

```bash
helm lint charts/omnia-arena-builder --strict \
  --set provider.name=p \
  --set sandbox.image.digest=sha256:0000000000000000000000000000000000000000000000000000000000000000
helm unittest --with-subchart=false charts/omnia-arena-builder

# The builder's sandbox tools through the runtime's MCP path, against the
# in-tree image (builds it first; needs docker):
make test-builder-sandbox

# The whole tool set through each provider's real tool conversion (needs helm):
go test -tags=integration -count=1 -run TestBuilderTools ./test/integration/

# One live request per provider with the builder's tool set, default settings.
# Each provider is skipped unless its key (ANTHROPIC_API_KEY, OPENAI_API_KEY,
# GEMINI_API_KEY) is set:
make test-live-providers
```
