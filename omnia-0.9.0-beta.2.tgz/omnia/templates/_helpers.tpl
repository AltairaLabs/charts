{{/*
Expand the name of the chart.
*/}}
{{- define "omnia.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "omnia.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "omnia.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "omnia.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "omnia.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
control-plane: controller-manager
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "omnia.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "omnia.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Manager image
*/}}
{{- define "omnia.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag }}
{{- printf "%s:%s" .Values.image.repository $tag }}
{{- end }}

{{/*
Dashboard fullname
*/}}
{{- define "omnia.dashboard.fullname" -}}
{{- printf "%s-dashboard" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Dashboard labels
*/}}
{{- define "omnia.dashboard.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.dashboard.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Dashboard selector labels
*/}}
{{- define "omnia.dashboard.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-dashboard
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: dashboard
{{- end }}

{{/*
Dashboard image
*/}}
{{- define "omnia.dashboard.image" -}}
{{- $tag := default .Chart.AppVersion .Values.dashboard.image.tag }}
{{- printf "%s:%s" .Values.dashboard.image.repository $tag }}
{{- end }}

{{/*
Dashboard service account name
*/}}
{{- define "omnia.dashboard.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "omnia.dashboard.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Compaction image
*/}}
{{- define "omnia.compaction.image" -}}
{{- $tag := default .Chart.AppVersion .Values.sessionRetention.compaction.image.tag }}
{{- printf "%s:%s" .Values.sessionRetention.compaction.image.repository $tag }}
{{- end }}

{{/*
Session API fullname
*/}}
{{- define "omnia.sessionApi.fullname" -}}
{{- printf "%s-session-api" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Session API labels
*/}}
{{- define "omnia.sessionApi.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.sessionApi.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Session API selector labels
*/}}
{{- define "omnia.sessionApi.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-session-api
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: session-api
{{- end }}

{{/*
Session API image
*/}}
{{- define "omnia.sessionApi.image" -}}
{{- $tag := default .Chart.AppVersion .Values.workspaceServices.sessionApi.image.tag }}
{{- printf "%s:%s" .Values.workspaceServices.sessionApi.image.repository $tag }}
{{- end }}

{{/*
Memory API fullname
*/}}
{{- define "omnia.memoryApi.fullname" -}}
{{- printf "%s-memory-api" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Memory API labels
*/}}
{{- define "omnia.memoryApi.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.memoryApi.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Memory API selector labels
*/}}
{{- define "omnia.memoryApi.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-memory-api
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: memory-api
{{- end }}

{{/*
Memory API image
*/}}
{{- define "omnia.memoryApi.image" -}}
{{- $tag := default .Chart.AppVersion .Values.workspaceServices.memoryApi.image.tag }}
{{- printf "%s:%s" .Values.workspaceServices.memoryApi.image.repository $tag }}
{{- end }}

{{/*
Doctor fullname
*/}}
{{- define "omnia.doctor.fullname" -}}
{{- printf "%s-doctor" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Doctor labels
*/}}
{{- define "omnia.doctor.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.doctor.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Doctor selector labels
*/}}
{{- define "omnia.doctor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-doctor
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: doctor
{{- end }}

{{/*
Doctor image
*/}}
{{- define "omnia.doctor.image" -}}
{{- $tag := default .Chart.AppVersion .Values.doctor.image.tag }}
{{- printf "%s:%s" .Values.doctor.image.repository $tag }}
{{- end }}

{{/*
Eval Worker fullname
*/}}
{{- define "omnia.evalWorker.fullname" -}}
{{- printf "%s-eval-worker" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Eval Worker labels
*/}}
{{- define "omnia.evalWorker.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.evalWorker.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Eval Worker selector labels
*/}}
{{- define "omnia.evalWorker.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-eval-worker
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: eval-worker
{{- end }}

{{/*
Eval Worker image
*/}}
{{- define "omnia.evalWorker.image" -}}
{{- $tag := default .Chart.AppVersion .Values.enterprise.evalWorker.image.tag }}
{{- printf "%s:%s" .Values.enterprise.evalWorker.image.repository $tag }}
{{- end }}

{{/*
Resolve OTLP tracing endpoint for runtime/facade containers.
Priority:
1. .Values.tracing.endpoint (explicit override)
2. Alloy service (when alloy.enabled=true)
3. Tempo service (when tempo.enabled=true)
Returns empty string when no endpoint can be resolved.
*/}}
{{- define "omnia.tracing.endpoint" -}}
{{- if .Values.tracing.endpoint -}}
{{- .Values.tracing.endpoint -}}
{{- else if .Values.alloy.enabled -}}
{{- printf "%s-alloy:4317" .Release.Name -}}
{{- else if .Values.tempo.enabled -}}
{{- printf "%s-tempo:4317" .Release.Name -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}
