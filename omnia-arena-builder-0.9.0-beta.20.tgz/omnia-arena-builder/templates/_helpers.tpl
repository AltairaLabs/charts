{{/*
The one name every object shares. The AgentRuntime, SandboxClass,
ToolRegistry, PromptPack, ConfigMap and ToolPolicy all carry it, so the
registry's sandbox handler class and the runtime's refs cannot drift apart.
*/}}
{{- define "arenaBuilder.name" -}}
{{- required "agent.name is required - it names the AgentRuntime and every object that makes it up." .Values.agent.name -}}
{{- end -}}

{{/*
Labels on every rendered object.

- omnia.altairalabs.ai/role: arena-builder says what the object is for.
- omnia.altairalabs.ai/module*: which Omnia module installed it, and at what
  version (tool-connectors design §3.2, renamed by §13.1).
*/}}
{{- define "arenaBuilder.commonLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.Version | quote }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | quote }}
omnia.altairalabs.ai/role: arena-builder
omnia.altairalabs.ai/module: {{ .Chart.Name }}
omnia.altairalabs.ai/module-version: {{ .Chart.Version | quote }}
{{- end -}}

{{/*
The common labels plus omnia.altairalabs.ai/hidden: "true", which keeps the
builder and its parts out of every list and picker a person sees
(api/v1alpha1/hidden.go). Lookups by name are unaffected, which is how the
dashboard finds the builder. Everything but the ToolPolicy carries it: a
permit is a governance object an admin audits, so it stays visible.
*/}}
{{- define "arenaBuilder.labels" -}}
{{ include "arenaBuilder.commonLabels" . }}
omnia.altairalabs.ai/hidden: "true"
{{- end -}}

{{/*
The sandbox image reference, pinned by digest. The tag is display only:
`repo:tag@digest` pulls by the digest.
*/}}
{{- define "arenaBuilder.sandboxImage" -}}
{{- $img := .Values.sandbox.image -}}
{{- $repo := required "sandbox.image.repository is required." $img.repository -}}
{{- $digest := required "sandbox.image.digest is required - the sandbox runs model-directed code, so its image is pinned by digest (sha256:...)." $img.digest -}}
{{- if not (regexMatch "^sha256:[a-f0-9]{64}$" $digest) -}}
{{- fail (printf "sandbox.image.digest must be sha256:<64 hex>, got %q" $digest) -}}
{{- end -}}
{{- if $img.tag -}}
{{- printf "%s:%s@%s" $repo $img.tag $digest -}}
{{- else -}}
{{- printf "%s@%s" $repo $digest -}}
{{- end -}}
{{- end -}}
