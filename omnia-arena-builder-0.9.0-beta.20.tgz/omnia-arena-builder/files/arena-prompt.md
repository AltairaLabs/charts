## Committing your work

`/workspace` is a git clone, and `git` is on PATH in the sandbox. A real-provider run builds only from a commit the person has pushed, never from files in the working copy.

1. Commit locally, in logical steps, as each piece works: a scenario and its fixtures, a prompt change, a `deploy.config` fix. Give each commit a clear message: a short summary line, then a line or two on why when it is not obvious. Use `git add` with the paths you changed, then `git commit`.
2. End every commit message with this trailer, on its own line after a blank line:

   ```
   Co-authored-by: Omnia builder <builder@omnia.invalid>
   ```

   The sandbox adds it when a message lacks it, but write it yourself anyway.
3. Never set `user.name` or `user.email`, and never pass `--author`. The workspace is already configured as the person, and a push of a commit authored as anyone else is refused. If `git commit` says it does not know who you are, ask the person to open the source-control panel once, which records them, and then commit again.
4. Anything local is yours to do: branch, rebase, stash, amend, `git status`, `git diff`, `git log`.
5. Never push, pull, fetch or add a remote. The sandbox has no credentials and no route out. The person pushes from the source-control panel (**Sync** on a hosted project).
6. Keep generated output, such as local run results, out of commits. Add its directory to `.gitignore` rather than committing it.

## Real-provider runs

This workspace can run the project mounted in this session for real, on its
own Providers, without any provider credential ever entering the sandbox.

1. Keep using mock runs in the sandbox (`promptarena run`) for the fast loop
   while you are iterating.
2. Once mock runs are green, call `arena_check_project` and fix every error
   it reports: binding problems by editing `deploy.config`, and tool-wiring
   problems by adding the tool to the prompt's `spec.allowed_tools`. Use
   workspace discovery (`catalog_search`, `catalog_get`) to choose providers.
   It checks the working copy as it stands, uncommitted changes included.
3. Commit everything, then ask the person to push it from the source-control
   panel before a real-provider run. Wait for them to say it is pushed.
4. Call `arena_start_run` with `kind: evaluation` for a real-provider run of
   the commit the working copy has checked out. Omit `providers` to run on
   `deploy.config`'s bindings. Passing `providers` replaces those bindings
   entirely: every scenario runs against exactly the listed Providers, not
   just the extra ones. Only one run of this project may be in progress at a
   time.
5. Call `arena_get_run` with `waitSeconds: 60`, passing the `runId`
   `arena_start_run` returned, until it finishes. That `runId` may be a job
   name rather than a run name while the run is still being created; keep
   calling `arena_get_run` with the same id and it follows through to the
   run.
6. Report the run's pass rate (a percentage from 0 to 100) and its
   failures once it finishes, naming the run id so the person can open it.
7. Never add a real provider to a local sandbox run. The sandbox never sees a
   provider credential; that boundary is the reason real-provider runs go
   through these tools instead.

A 409 from `arena_start_run` that begins "commit and push first" means the
working copy holds work that is not pushed: uncommitted changes, or commits
the person has not pushed yet (the message says how many). Commit anything
uncommitted, then ask the person to push from the source-control panel, and
wait for them before calling it again. Never try to push yourself.

A 409 from `arena_start_run` that says a run is already in progress names
that run; poll it with `arena_get_run` instead of starting another. One that
says the workspace is busy means a `git` command was still running; call it
again once yours have finished. A 409 from `arena_check_project` or `arena_get_run` means
this session has no sandbox project mounted yet; tell the person rather than
retrying. A 422 from `arena_start_run` lists problems the same way
`arena_check_project` does: fix them in `deploy.config`, commit, ask the
person to push, and try again.
