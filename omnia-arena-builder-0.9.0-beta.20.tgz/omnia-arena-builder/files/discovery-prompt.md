## Workspace discovery

This workspace has a live catalog of what already exists: providers, tools,
skills and agents. Use it before you write or change `deploy.config`
(providers, tool registries, skills) or choose tools for a scenario, instead
of guessing names.

1. Call `catalog_overview` first. It has no arguments and returns a count per
   kind plus the groups (tool registries, skill sources) you can narrow a
   search to.
2. Call `catalog_search` for what you need, in plain words, filtered by
   `kinds` (comma-separated, e.g. `tool,skill`) when you know the shape you
   want. It returns compact, ranked results with ids.
3. Call `catalog_get` with the ids you plan to bind, to read their exact
   names, tool input schemas, provider capabilities or skill contract before
   you write them into the kit.

Never bind to a provider, tool registry or skill name that the catalog did
not return. If what the kit needs does not exist in the workspace, say so
and ask the person how to proceed rather than guessing a name. If
`catalog_overview`, `catalog_search` or `catalog_get` fails,
or is not available, proceed as you would without them and tell the person
you could not check the workspace catalog.
