# Omnia Helm chart

Deploys [Omnia](https://omnia.altairalabs.ai) — a Kubernetes operator for AI agent orchestration — to a Kubernetes cluster.

This chart installs:

- **Operator** (`cmd/main.go`) — controller-manager reconciling AgentRuntime, PromptPack, ToolRegistry, Provider, Workspace, and SessionRetentionPolicy CRDs. Also serves the content, deploy, tool-test and sandbox APIs.
- **Dashboard** (`dashboard/`) — the UI for agent consoles, session browsing, and admin: a static Next.js export served by nginx, with no server code.
- **Management API** (`cmd/management-api/`) — every `/api` route the dashboard calls: sign-in, API keys, workspace RBAC, Kubernetes access and the management-plane signing key. Deployed with the dashboard.
- **Eval worker** (per-namespace) — executes realtime evals against active agent sessions.
- **Session retention** — default `SessionRetentionPolicy` (cluster default).
- **Optional: Arena / Enterprise** — prompt testing, evaluation, policy proxy (`enterprise.enabled: true`).
- **Optional: observability subcharts** — Prometheus, Grafana, Loki, Tempo, Alloy (all off by default).
- **Optional: workload plumbing** — NFS server/CSI for workspace content, KEDA for autoscaling, Redis for Arena queue.

The chart **does not** include sample AgentRuntime/Workspace CRs — you create those.

---

## Minimum install

Every install **must** set these two values. The chart refuses to render without them.

| Value | Why |
|---|---|
| `dashboard.auth.mode` | One of `oauth`, `builtin`, `proxy`, `anonymous`. No default — prevents accidental unauthenticated deploys. |
| `dashboard.auth.allowAnonymous: true` | Only required when `mode: anonymous`. Explicit opt-in. |

> **`--devel` is required for now.** Omnia currently publishes only pre-release
> (beta) charts, and `helm install`/`upgrade` **skip pre-release versions by
> default** — without `--devel` the command fails with `no chart version found`.
> Every command below includes it. Once a stable (non-beta) release is cut,
> `--devel` is no longer needed. (Alternatively, pin an exact `--version <x.y.z-beta.N>`.)

CRDs install first, as their own release. The app chart refuses to install
without them, and `helm upgrade` of the app chart never updates them — that is
the whole reason they are a separate chart:

```bash
helm install omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds \
  --devel \
  --namespace omnia-system --create-namespace
```

This installs every kind, the Enterprise ones (Arena, ToolPolicy,
RolloutAnalysis, SessionPrivacyPolicy, PromptPackSource) included, so turning
Enterprise on later needs no CRD step. Pass `--set enterprise.enabled=false` to
leave the Enterprise kinds out.

Smallest possible install (local kind/k3d, no auth):

```bash
helm install omnia oci://ghcr.io/altairalabs/charts/omnia \
  --devel \
  --namespace omnia-system \
  --set dashboard.auth.mode=anonymous \
  --set dashboard.auth.allowAnonymous=true
```

For a real cluster you also need Postgres access for the session store and usually a storage class for workspace content. See the three deployment profiles below.

---

## Deployment profiles

Three starting points, from least to most featureful. Each points at a `values-*.yaml` file in this directory (examples coming in a follow-up PR — tracked in [#895](https://github.com/AltairaLabs/Omnia/issues/895)).

### 1. Development (single machine, kind/k3d/Docker Desktop)

Goal: install Omnia with zero external dependencies. Dev Postgres + NFS server both deployed inline.

CRDs first (see [CRDs](#crds) below), then:

```bash
helm install omnia oci://ghcr.io/altairalabs/charts/omnia \
  --devel \
  --values values-dev.yaml \
  --set dashboard.auth.mode=anonymous \
  --set dashboard.auth.allowAnonymous=true
```

What you get:
- Operator (1 replica), Dashboard (1 replica, anonymous auth).
- Dev Postgres (in-cluster, NOT production-safe — see `dev.postgres` in charts/omnia-dev).
- NFS server + CSI driver for workspace content (dev-only).
- No enterprise, no observability, no license.

### 2. Production (OSS, no Arena)

Goal: multi-replica operator/dashboard on real infra, OAuth, external Postgres, external storage class for workspace content.

Required values file (create as `values-prod.yaml`):

```yaml
# Auth
dashboard:
  auth:
    mode: oauth
  oauth:
    provider: generic       # or google, okta, azure
    issuerUrl: https://idp.example.com
    existingSecret: omnia-oauth   # keys OMNIA_OAUTH_CLIENT_ID and OMNIA_OAUTH_CLIENT_SECRET

# Sign-in sessions: a Redis every management-api replica shares. Required
# with managementApi.replicaCount above 1; the chart refuses to render without
# it then.
redis:
  default:
    existingSecret:
      name: omnia-redis   # a Secret whose `url` key is the Redis URL
      key: url

# Session store
postgres:
  dev:
    enabled: false    # use external Postgres via Workspace CRs instead

# Workspace content (always provisioned; RWX required — use EFS / Azure Files / Filestore)
workspaceContent:
  persistence:
    storageClassName: efs-sc    # AWS example
    size: 100Gi

# High availability
replicaCount: 3
dashboard:
  replicaCount: 2
  podDisruptionBudget:
    enabled: true
  # Keep open tabs working across upgrades (needs ReadWriteMany with 2+
  # replicas; see Upgrading below).
  staticAssets:
    persistence:
      enabled: true
      storageClassName: efs-sc
```

Install (CRDs first, see [CRDs](#crds) below):

```bash
helm install omnia oci://ghcr.io/altairalabs/charts/omnia --devel --values values-prod.yaml
```

### 3. Enterprise (Arena + advanced features)

Requires an Omnia enterprise license. Add on top of the production profile:

```yaml
license:
  existingSecret: omnia-license

enterprise:
  enabled: true

  # Community templates source reaches out to github.com on each sync, into
  # the default workspace's gallery. On by default; false for air-gapped:
  communityTemplates:
    enabled: true

  arena:
    queue:
      type: redis
      redis:
        host: "omnia-redis-master"
        port: 6379

redis:
  enabled: true
```

Install CRDs with Enterprise enabled first (see [CRDs](#crds) below), then:

```bash
helm install omnia oci://ghcr.io/altairalabs/charts/omnia \
  --devel \
  --values values-prod.yaml \
  --values values-enterprise.yaml
```

---

## Cloud-native add-ons

Plug Omnia into your cloud's native identity and secret-store features via `PodOverrides` on per-workspace and per-agent CRs. See the [Configure Pod Overrides](https://omnia.altairalabs.ai/docs/how-to/configure-pod-overrides) how-to for the full reference.

Short summary of placements:

| CRD | Field | Common use |
|---|---|---|
| `AgentRuntime.spec.podOverrides` | facade + runtime pod | workload identity SA, CSI-mounted provider keys, GPU nodeSelector |
| `AgentRuntime.spec.evals.podOverrides` | eval-worker (per service group) | batch-node affinity |
| `Workspace.spec.services[].session.podOverrides` | session-api | CSI-synced DB password via envFrom |
| `Workspace.spec.services[].memory.podOverrides` | memory-api | CSI-synced embedding-provider key |
| `ArenaJob.spec.workers.podOverrides` | worker Jobs | per-job provider credential CSI mount |

For chart-owned deployments (operator, dashboard, arena-controller) use the inline `extraEnv` / `extraEnvFrom` / `extraVolumes` / `extraVolumeMounts` values. A unified `podOverrides:` block for these is planned in the chart overhaul ([#895 W4](https://github.com/AltairaLabs/Omnia/issues/895)).

---

## Internal service authentication (session-api)

The operator-managed per-workspace **session-api** (the session CRUD JSON API and
its optional OTLP listeners) is protected by ServiceAccount-token authentication.
This is controlled by `internalServiceAuth` and is **on by default** (secure by
default, [#1720](https://github.com/AltairaLabs/Omnia/issues/1720)).

**Trust boundary.** With `internalServiceAuth.enabled: true`, session-api rejects
any request that does not carry a valid Kubernetes ServiceAccount bearer token:

- Every caller presents an **audience-bound projected SA token** (`audience:
  omnia-session-api`) and sends it as `Authorization: Bearer <token>`.
- session-api validates the token server-side via the Kubernetes **TokenReview**
  API and authorizes the caller when its ServiceAccount subject is in the
  allowlist **or** its ServiceAccount namespace is the workspace namespace.
- The chart/operator wire this automatically for every caller they manage:
  the facade/agent, memory-api and eval-worker (authorized by namespace) and the
  cross-namespace operator, Doctor and management-api SAs (authorized as
  exact-match subjects). The dashboard is static files and calls nothing.
- Two defence-in-depth layers ride on the same switch: a default-deny-ingress
  **NetworkPolicy** on the session-api/memory-api pods (a no-op on clusters whose
  CNI does not enforce NetworkPolicy — the TokenReview gate still applies), and
  an optional STRICT Istio **PeerAuthentication** via
  `internalServiceAuth.istio.enabled`.

**When to disable.** Set `internalServiceAuth.enabled: false` only if you run a
**custom, non-enumerated caller** of session-api that cannot present an SA token.
It will otherwise receive `401`s. Prefer adding its ServiceAccount to the
allowlist over turning the gate off wholesale.

**OTLP senders.** session-api's OTLP listeners (`--otlp-enabled`) are gated by the
same auth. The default chart trace path is `agents → alloy → Tempo` only (no
alloy→session-api exporter), so nothing needs a bearer token out of the box. If
you add an OTLP exporter that targets session-api while auth is on, that sender
**must** present its own projected SA token. See `cmd/session-api/SERVICE.md`.

**Upgrade note.** Turning this on (now the default) makes session-api reject
tokenless callers. All in-tree callers already send tokens, so upgrades of a
stock install are transparent — but if you had a bespoke integration talking to
session-api directly, allowlist its SA or set `internalServiceAuth.enabled:
false` before upgrading.

---

## Upgrading

Before each upgrade:

1. Re-read the [CHANGELOG](https://github.com/AltairaLabs/Omnia/releases) for the target version.
2. Run `helm diff upgrade omnia <chart> --values values-*.yaml` (install the `helm-diff` plugin).
3. Back up the session-api database.
4. Upgrade one release at a time where the release notes name a required
   stop. One does: an install of v0.9.0-beta.20 with
   `dashboard.persistence.enabled` must pass through the release that
   annotates its `<release>-dashboard-data` claim `keep`, or a later upgrade
   deletes the claim and the users on it.

### Open dashboard tabs

A browser tab opened before an upgrade keeps asking for the previous build's
JavaScript chunks, which the new dashboard pods do not have. By default the
dashboard recovers on its own: it reloads the page once when a chunk fails to
load, and offers a reload when it sees a newer build. To keep those tabs
working instead, turn on the shared chunk store:

```yaml
dashboard:
  staticAssets:
    persistence:
      enabled: true
      storageClassName: <a ReadWriteMany class>   # Azure Files, EFS, Filestore, NFS
```

Each dashboard pod copies its build's `/_next/static/` into the volume and
keeps the newest `dashboard.staticAssets.keepBuilds` (3); nginx serves a chunk
from its own image first and from the volume second. More than one replica
needs `ReadWriteMany`. With one replica, `accessModes: [ReadWriteOnce]` works:
the chart then switches the dashboard Deployment to `Recreate`, because a
ReadWriteOnce volume cannot attach to the old and new pods on different nodes
(override with `dashboard.updateStrategy`). The store is a cache: if a pod
cannot update it, the pod still starts and serves its own build. It protects
the upgrades after the one that enables it. See the
[Helm values reference](https://omnia.altairalabs.ai/reference/platform/helm-values/#open-tabs-across-upgrades).

### CRDs

Omnia's CRDs are a separate chart, `omnia-crds`, and a separate release. See
[`charts/omnia-crds/README.md`](../omnia-crds/README.md).

Two things follow, and both are the opposite of how `crds/` behaved:

- **They upgrade.** `helm upgrade omnia-crds` applies schema changes and creates
  newly enabled enterprise kinds. Always upgrade the CRDs before the app chart;
  the app chart's preflight enforces `omnia-crds >= omnia`.
- **Nothing deletes them.** Every CRD carries `helm.sh/resource-policy: keep`, so
  `helm uninstall omnia-crds` leaves them and every custom resource alone.
  Removing them for real is `kubectl delete crd`, and it cascades to every
  Workspace, AgentRuntime, PromptPack, ToolPolicy and SandboxClaim in the
  cluster.

Upgrading an install that predates the split needs one step first — CRDs created
by Helm's `crds/` mechanism carry no ownership metadata:

```bash
hack/adopt-crds.sh --context <ctx> --release-namespace omnia-system
```

**Seeing a raw `namespaces "kube-system" is forbidden: ...` instead of one of
the messages above?** The preflight probes for the CRDs with Helm's `lookup`,
which aborts the render on any API error other than NotFound — including an
RBAC `Forbidden` from a restricted installer identity (e.g. Azure's
cluster-extension service account). That identity cannot get namespaces; set
`crdPreflight.enabled=false` to turn the probe off. See
[`charts/omnia-crds/README.md`](../omnia-crds/README.md) for detail.

### Pseudonym key

The chart names the pseudonym key's Secret (`pseudonymKey`); the operator
creates it at startup when it does not exist. A new install gets a random key.
An install that already has Workspaces or AgentRuntimes is recorded as
unkeyed, because a new key would change the pseudonym of every person already
stored. The chart renders no key, so `helm template`, Argo CD and Flux cannot
change it.

The install key never leaves the release namespace. Each Workspace
pseudonymises under its own key, derived from the install key with the
Workspace's UID (HKDF-SHA256), which the operator writes as
`omnia-workspace-pseudonym-key` into the workspace namespace. session-api,
memory-api and privacy-api bind their databases to their workspace's key and
refuse another. management-api and doctor read the install key as
`OMNIA_PSEUDONYM_INSTALL_KEY` and derive each workspace's per request.

Reading Secrets in a workspace namespace exposes that workspace's key alone:
it cannot compute anyone's pseudonym in another workspace. A key once set by
hand as `OMNIA_PSEUDONYM_HMAC_KEY` cannot be adopted with its pseudonyms
intact; remove it from every `extraEnv` / `podOverrides`. The chart refuses
values that would change an existing install's key. See
[Pseudonym key](https://omnia.altairalabs.ai/reference/platform/privacy-api/#pseudonym-key).

---

## Uninstalling

```bash
helm uninstall omnia
```

This removes all resources **except**:
- The CRDs — they live in the separate `omnia-crds` release, untouched by `helm uninstall omnia`. See [CRDs](#crds) above.
- PersistentVolumeClaims (keep data; delete manually if you're sure)
- `omnia-system` namespace (if the chart created it)

---

## Gotchas

A selection of things that will bite you if you don't know about them:

- **`dashboard.auth.mode` is required.** The chart intentionally has no default — avoids accidentally deploying with no auth.
- **Workspace-content storage is always provisioned and Omnia requires a ReadWriteMany (RWX) StorageClass.** This is not a toggle — the operator writes SkillSource content into the workspace-content PVC and serves it via the content API; skills and arena read from it, so Omnia does not function without it. Azure Disk, AWS EBS, and GKE PD are NOT RWX and will fail to provision this volume. Use Azure Files, EFS, Filestore, NFS, or an RWX CSI driver and set `workspaces.storage.storageClass` / `workspaceContent.persistence.storageClass` accordingly. ReadWriteOnce is acceptable only on single-node clusters (e.g. local kind dev).
- **Single-replica PDBs are refused.** `podDisruptionBudget.enabled=true` with `replicaCount: 1` renders a template `fail` — otherwise every drain/rollout would be permanently blocked. Either raise replicas or set `podDisruptionBudget.maxUnavailable: 1`.
- **Dev Postgres (`dev.postgres.enabled`) is dev-only**, and lives in the `charts/omnia-dev` subchart so a production install never carries it at all (`dev.enabled` is false by default). No volume persistence; restart loses data. Production installs MUST use external Postgres via a Secret referenced by the `Workspace` CR.
- **The chart's custom resources belong to the operator, not this release.** The starter Workspace, default privacy and retention policies, compliance presets, and sandbox classes and registries are installed by the operator as a Helm release of its own, `omnia-resources`, from the values this chart puts in the `<release>-resources-values` ConfigMap — the one arrangement that works the same under Helm, Azure's cluster extension and GCP's deployer. `helm list -n <namespace>` shows both releases; a failure to install them is a Warning event on that ConfigMap. **`helm uninstall omnia` leaves that release behind**, because the operator is removed in the same step: run `helm uninstall omnia-resources -n <namespace>` afterwards to remove the policies and sandbox classes. The starter Workspace and its namespace are kept either way, with their data. **Upgrading a release that predates this** refuses with a `fail` until you run `kubectl annotate workspace <name> helm.sh/resource-policy=keep`: Helm deletes whatever leaves the release, and the operator's finalizer would take the workspace's PVCs with it.
- **Community templates (`enterprise.communityTemplates.enabled`) reach out to GitHub.** On by default: an ArenaTemplateSource for github.com/AltairaLabs/promptkit-templates in the default workspace (`defaultWorkspace.enabled`), so its New project gallery has templates. A template source must live in a workspace, so nothing renders without one. Set it `false`, or set `airGapped: true`, for an air-gapped install. `airGapped: true` turns off every outbound call the chart makes by default; see [Outbound connections](https://omnia.altairalabs.ai/reference/platform/outbound-connections/).
- **CRDs are a separate chart and release, `omnia-crds`, not a subchart of this one.** It installs the Enterprise kinds by default, so enabling `enterprise.enabled: true` on this chart needs no CRD step; the dashboard no longer creates CRDs on licence upload (#2700). See [CRDs](#crds) above and [`charts/omnia-crds/README.md`](../omnia-crds/README.md).
- **Large CRDs overflow client-side `kubectl apply`.** `hack/adopt-crds.sh` and `make install` already use `--server-side --force-conflicts`; do the same for any manual apply of the CRD chart's templates. See `charts/omnia-crds/README.md`'s "Applying them by hand" section.
- **Agent metrics are discovered by a `metrics`-named container port, not by `prometheus.io/port`.** An agent pod serves Prometheus metrics on two ports across two containers — the facade on 8081 and the runtime on 9001 — with no in-pod consolidation, so a single `prometheus.io/port` annotation can't express both (it used to point at 8080, which has no `/metrics`, so facade metrics were never scraped — see #1488). Both containers instead declare a container port **named `metrics`**; the bundled Prometheus `omnia-agents` job and the optional `podMonitor` (for an external Prometheus Operator) both key on that port name, so one job covers both endpoints regardless of port number or which facade/runtime image is deployed. Under Istio sidecars the operator excludes both metrics ports from inbound mTLS interception so the direct scrape still works (no reliance on `merge-metrics`).
- **Grafana dashboard ConfigMaps render only when `grafana.enabled`.** They're labeled for discovery by Grafana's sidecar — harmless if missing, but not orphaned.
- **session-api requires ServiceAccount auth by default (`internalServiceAuth.enabled: true`).** Tokenless callers get `401`. All in-tree callers (facade, management-api, memory-api, eval-worker) send tokens automatically; a bespoke direct caller must be allowlisted or you must set `internalServiceAuth.enabled: false`. See [Internal service authentication](#internal-service-authentication-session-api).

---

## Values reference

A full values table is generated from `values.yaml` comments. Browse:

- [`values.yaml`](./values.yaml) — canonical source with inline documentation for every knob
- [`values.schema.json`](./values.schema.json) — JSON Schema validation (completion in progress — [#895 W2](https://github.com/AltairaLabs/Omnia/issues/895))
- [`values-dev.yaml`](./values-dev.yaml) — local development
- [`values-dev-enterprise.yaml`](./values-dev-enterprise.yaml) — local development + enterprise
- [`values-demo-observability.yaml`](./values-demo-observability.yaml) — all observability subcharts on

More worked examples (Azure KV CSI, AWS IRSA, GKE Workload Identity) coming in [#895 W5](https://github.com/AltairaLabs/Omnia/issues/895).

---

## Contributing

See the [chart overhaul proposal](https://github.com/AltairaLabs/Omnia/issues/895) for the active improvement plan. File issues at https://github.com/AltairaLabs/Omnia/issues.

Pre-commit checks for chart changes:

- `helm lint --strict charts/omnia`
- `hack/validate-helm.sh` (helm template renders with default and enterprise values)
- `helm unittest charts/omnia` (local only; CI coverage coming in [#895 W6](https://github.com/AltairaLabs/Omnia/issues/895))
