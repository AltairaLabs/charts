{{/*
airGapped (#3482): one value that turns off every outbound call the chart's
components make by default. The list of destinations, with the value that
turns each off, is docs/src/content/docs/reference/platform/outbound-connections.md;
keep the two in step.

Precedence, and why it differs by setting:

- A default-ON call (install telemetry, licence activation, the GitHub
  community templates source) is OVERRIDDEN. Its value defaults to on, so the
  chart cannot tell a deliberate `true` from the default, and failing on it
  would make every air-gapped install set three more values to say the same
  thing.
- A default-OFF setting that names an outside host FAILS the render. Each one
  was asked for, so dropping it silently would leave a marketplace install
  unbilled or a pack unvalidated with nothing to say why.

hack/check-air-gapped-render.sh renders the chart with airGapped=true and
fails on any URL outside the cluster in the output.
*/}}

{{/*
omnia.communityTemplatesURL is the GitHub source the community templates
default to. airGapped turns the source off only while it points here: a url
changed to an in-cluster mirror is the operator's own choice and stays.
*/}}
{{- define "omnia.communityTemplatesURL" -}}
https://github.com/AltairaLabs/promptkit-templates.git
{{- end }}

{{/*
omnia.validateAirGapped fails the render when airGapped is set together with
a value that names a host outside the cluster.
*/}}
{{- define "omnia.validateAirGapped" -}}
{{- if .Values.airGapped }}
{{- $conflicts := list }}
{{- if eq (dig "promptPackSchema" "source" "embedded" .Values.operator) "network" }}
{{- $conflicts = append $conflicts "operator.promptPackSchema.source=network fetches PromptPack schemas from promptpack.org (use embedded)" }}
{{- end }}
{{- if .Values.controlPlane.url }}
{{- $conflicts = append $conflicts "controlPlane.url registers the install with the Commercial Control Plane" }}
{{- end }}
{{- if (.Values.awsMarketplace).productSku }}
{{- $conflicts = append $conflicts "awsMarketplace.productSku checks the entitlement with AWS License Manager" }}
{{- end }}
{{- if (.Values.gcpMarketplace).reportingSecret }}
{{- $conflicts = append $conflicts "gcpMarketplace.reportingSecret reports usage to Google Service Control" }}
{{- end }}
{{- if and .Values.grafana.enabled .Values.grafana.plugins }}
{{- $conflicts = append $conflicts "grafana.plugins are downloaded from grafana.com when Grafana starts (set grafana.plugins=[] and bake plugins into a mirrored image)" }}
{{- end }}
{{- if ((.Values.dashboard).avatars).gravatar }}
{{- $conflicts = append $conflicts "dashboard.avatars.gravatar has every signed-in user's browser load their picture from www.gravatar.com" }}
{{- end }}
{{- if $conflicts }}
{{- fail (printf "airGapped=true contacts no host outside the cluster, but: %s" (join "; " $conflicts)) }}
{{- end }}
{{- end }}
{{- end }}

{{/*
omnia.telemetryEnabled is the operator's OMNIA_TELEMETRY_ENABLED: off on an
air-gapped install whatever telemetry.enabled says.
*/}}
{{- define "omnia.telemetryEnabled" -}}
{{- and .Values.telemetry.enabled (not .Values.airGapped) -}}
{{- end }}

{{/*
omnia.gravatarEnabled is the dashboard's OMNIA_GRAVATAR_ENABLED (#3505).
airGapped already refuses dashboard.avatars.gravatar=true; the `not` keeps
the ConfigMap from ever saying true on an air-gapped install regardless.
*/}}
{{- define "omnia.gravatarEnabled" -}}
{{- and (((.Values.dashboard).avatars).gravatar | default false) (not .Values.airGapped) -}}
{{- end }}

{{/*
omnia.communityTemplatesForwarded is enterprise.communityTemplates as the
omnia-resources release receives it: with enabled=false on an air-gapped
install while its url is still the GitHub default, and without that url, so
the values ConfigMap names no outside host either.
*/}}
{{- define "omnia.communityTemplatesForwarded" -}}
{{- $ct := deepCopy .Values.enterprise.communityTemplates }}
{{- if and .Values.airGapped (eq ($ct.url | default (include "omnia.communityTemplatesURL" .)) (include "omnia.communityTemplatesURL" .)) }}
{{- $_ := set $ct "enabled" false }}
{{- $_ = unset $ct "url" }}
{{- end }}
{{- toYaml $ct }}
{{- end }}
