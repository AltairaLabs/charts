{{- /*
The install's pseudonym key (#2316).

Every user identifier Omnia stores is a pseudonym: HMAC-SHA256 of the raw id
under its workspace's key, or plain SHA-256 with no key. Each workspace's key
is derived from the install key (HKDF-SHA256 salted with the Workspace's UID,
#3563), so the install key never leaves the release namespace and reading
Secrets in one workspace namespace exposes that workspace's key alone. A pseudonym
cannot be recomputed after the fact, so two processes with two keys split one
person into two identities nobody can join again — DSAR erasure then reports
success having deleted half of them.

The chart names the key's Secret; it never generates the key. `lookup` sees
nothing under `helm template`, Argo CD or Flux, so a chart-generated key would
change on every render. The OPERATOR creates the Secret at startup when it
does not exist (--pseudonym-key-create): a random key on a new install, or —
when Workspaces or AgentRuntimes already exist — an unkeyed marker (empty
`key`, `required: "false"`), because a key generated under existing data
would change every stored pseudonym. Concurrent operator replicas are safe.

  - The operator reads the Secret itself (it creates it, so a secretKeyRef on
    its own pod could not resolve on a first install).
  - management-api and doctor act across workspaces: they read it as
    OMNIA_PSEUDONYM_INSTALL_KEY through a secretKeyRef and derive each
    workspace's key per request; until the operator has created it they wait
    in CreateContainerConfigError.
  - The operator and arena-controller write each workspace's DERIVED key as
    omnia-workspace-pseudonym-key beside every facade, eval and arena worker,
    session-api, memory-api and privacy-api; the agent runtime gets only its
    fingerprint.
  - pseudonymKey.existingSecret: a Secret you manage instead (KMS / CSI, or a
    key you already set by hand — see the upgrade notes). It must hold a key.

Every database that holds pseudonyms is bound to the key's fingerprint and
refuses another, so a mistake here fails loudly rather than silently.
*/ -}}

{{/* Default name of the Secret the operator creates. */}}
{{- define "omnia.pseudonymKey.generatedName" -}}
{{- printf "%s-pseudonym-key" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Name of the Secret consumers read the key from; empty when disabled. */}}
{{- define "omnia.pseudonymKey.secretName" -}}
{{- $pk := .Values.pseudonymKey | default dict -}}
{{- if $pk.enabled -}}
{{- $pk.existingSecret | default $pk.secretName | default (include "omnia.pseudonymKey.generatedName" .) -}}
{{- end -}}
{{- end -}}

{{/* Key within the Secret. */}}
{{- define "omnia.pseudonymKey.secretKey" -}}
{{- $pk := .Values.pseudonymKey | default dict -}}
{{- if $pk.existingSecret -}}
{{- $pk.existingSecretKey | default "key" -}}
{{- else -}}
key
{{- end -}}
{{- end -}}

{{/*
Env for a chart-owned container that acts across workspaces (management-api,
doctor): the INSTALL key, under its own variable so it is never mistaken for a
workspace key; the process derives each workspace's key from it.
The key reference is not optional: a pod whose Secret does not exist yet waits
for the operator to create it. OMNIA_PSEUDONYM_KEY_REQUIRED comes from the
operator-created Secret's `required` ("false" for an install that stays
unkeyed); an existingSecret must hold a key, so it is "true".
*/}}
{{- define "omnia.pseudonymKey.env" -}}
{{- with include "omnia.pseudonymKey.secretName" . }}
- name: OMNIA_PSEUDONYM_INSTALL_KEY
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: {{ include "omnia.pseudonymKey.secretKey" $ }}
{{- if $.Values.pseudonymKey.existingSecret }}
- name: OMNIA_PSEUDONYM_KEY_REQUIRED
  value: "true"
{{- else }}
- name: OMNIA_PSEUDONYM_KEY_REQUIRED
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: required
{{- end }}
{{- end }}
{{- end -}}

{{/* Flags for the operator (which creates the Secret) and arena-controller. */}}
{{- define "omnia.pseudonymKey.args" -}}
{{- with include "omnia.pseudonymKey.secretName" . }}
- --pseudonym-key-secret-name={{ . }}
- --pseudonym-key-secret-key={{ include "omnia.pseudonymKey.secretKey" $ }}
{{- end }}
{{- end -}}

{{/* The operator alone creates the Secret, and only when it is not yours. */}}
{{- define "omnia.pseudonymKey.operatorArgs" -}}
{{- include "omnia.pseudonymKey.args" . }}
{{- if and (include "omnia.pseudonymKey.secretName" .) (not .Values.pseudonymKey.existingSecret) }}
- --pseudonym-key-create=true
{{- end }}
{{- end -}}

{{/*
Best-effort render-time checks. `lookup` sees nothing under `helm template`,
so these never fire there; the databases' own fingerprint check is the
backstop.
*/}}
{{- define "omnia.pseudonymKey.validate" -}}
{{- $pk := .Values.pseudonymKey | default dict -}}
{{- $generated := "" -}}
{{- $g := lookup "v1" "Secret" .Release.Namespace (include "omnia.pseudonymKey.generatedName" .) -}}
{{- if and $g $g.data (hasKey $g.data "key") -}}
{{- $generated = index $g.data "key" -}}
{{- end -}}
{{- if $generated -}}
{{- if not $pk.enabled -}}
{{- fail (printf "pseudonymKey.enabled=false would drop the pseudonym key this install runs with (Secret %s): every service bound to it would refuse to start. Changing the key is a migration, not a values edit — see the pseudonymisation upgrade notes" (include "omnia.pseudonymKey.generatedName" .)) -}}
{{- end -}}
{{- with $pk.existingSecret -}}
{{- $s := lookup "v1" "Secret" $.Release.Namespace . -}}
{{- $k := $pk.existingSecretKey | default "key" -}}
{{- if and $s $s.data (hasKey $s.data $k) (ne (index $s.data $k) $generated) -}}
{{- fail (printf "pseudonymKey.existingSecret %s holds a different key from the one this install runs with (Secret %s): every service bound to that key would refuse to start. Copy that key into your Secret, or leave existingSecret unset" . (include "omnia.pseudonymKey.generatedName" $)) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- with $pk.existingSecret -}}
{{- if and (lookup "v1" "Namespace" "" $.Release.Namespace) (not (lookup "v1" "Secret" $.Release.Namespace .)) -}}
{{- fail (printf "pseudonymKey.existingSecret %s does not exist in namespace %s: create it (key %q) before installing" . $.Release.Namespace ($pk.existingSecretKey | default "key")) -}}
{{- end -}}
{{- end -}}
{{- if include "omnia.pseudonymKey.secretName" . -}}
{{- range $component, $env := dict "operator" (concat ($.Values.operator.extraEnv | default list) (dig "podOverrides" "extraEnv" list $.Values.operator)) "managementApi" (dig "podOverrides" "extraEnv" list $.Values.managementApi) "doctor" (dig "podOverrides" "extraEnv" list $.Values.doctor) -}}
{{- range $env -}}
{{- if has (.name | default "") (list "OMNIA_PSEUDONYM_HMAC_KEY" "OMNIA_PSEUDONYM_INSTALL_KEY") -}}
{{- fail (printf "%s sets %s in extraEnv while the chart manages the pseudonym key (pseudonymKey): one install, one key. Remove it, or put that key in a Secret and name it in pseudonymKey.existingSecret" $component .name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
