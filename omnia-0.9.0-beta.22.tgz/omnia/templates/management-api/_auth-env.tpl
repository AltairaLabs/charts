{{- /*
  The dashboard's auth configuration, from dashboard.auth, .proxy and .oauth,
  for management-api (#2632), which signs every user in and reads it with
  internal/mgmtapi/auth/config.go. The dashboard ConfigMap carries the
  mode-level variables too (configmap.yaml), which management-api reads for
  GET /api/v1/config; both are rendered from the same values, so the two
  cannot disagree. The public origin, omnia.dashboard.baseUrl, is
  _builtin.tpl's.
*/ -}}

{{- /*
  omnia.dashboard.sessionSecretEnv: OMNIA_SESSION_SECRET, in every mode that
  seals a session cookie — a literal, an operator-managed Secret, or the one
  session-secret.yaml generated. An env list, unindented.
*/ -}}
{{- define "omnia.dashboard.sessionSecretEnv" -}}
{{- if and (ne .Values.dashboard.auth.mode "anonymous") .Values.dashboard.auth.sessionSecret }}
- name: OMNIA_SESSION_SECRET
  value: {{ .Values.dashboard.auth.sessionSecret | quote }}
{{- else if and (ne .Values.dashboard.auth.mode "anonymous") .Values.dashboard.auth.existingSessionSecret }}
- name: OMNIA_SESSION_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.dashboard.auth.existingSessionSecret }}
      key: OMNIA_SESSION_SECRET
{{- else if ne .Values.dashboard.auth.mode "anonymous" }}
# Neither a literal nor an operator-managed Secret was supplied, so
# session-secret.yaml generated one. Without this arm management-api
# falls back to the development session secret that is checked into
# this repository, and seals real session cookies with a value
# anyone can read.
- name: OMNIA_SESSION_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-session-secret" (include "omnia.dashboard.fullname" .) }}
      key: OMNIA_SESSION_SECRET
{{- end }}
{{- end -}}

{{- /*
  omnia.dashboard.oauthClientEnv: the OAuth client id and secret in oauth
  mode, from dashboard.oauth.existingSecret or the literal values. An env
  list, unindented.
*/ -}}
{{- define "omnia.dashboard.oauthClientEnv" -}}
{{- if eq .Values.dashboard.auth.mode "oauth" }}
{{- if .Values.dashboard.oauth.existingSecret }}
- name: OMNIA_OAUTH_CLIENT_ID
  valueFrom:
    secretKeyRef:
      name: {{ .Values.dashboard.oauth.existingSecret }}
      key: OMNIA_OAUTH_CLIENT_ID
- name: OMNIA_OAUTH_CLIENT_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ .Values.dashboard.oauth.existingSecret }}
      key: OMNIA_OAUTH_CLIENT_SECRET
{{- else }}
{{- if .Values.dashboard.oauth.clientId }}
- name: OMNIA_OAUTH_CLIENT_ID
  value: {{ .Values.dashboard.oauth.clientId | quote }}
{{- end }}
{{- if .Values.dashboard.oauth.clientSecret }}
- name: OMNIA_OAUTH_CLIENT_SECRET
  value: {{ .Values.dashboard.oauth.clientSecret | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- /*
  omnia.managementApi.authEnv: the rest of the dashboard's sign-in
  configuration for management-api's auth core (always built since the
  cut-over, #2632 5-7): the session cookie and its secret, the PKCE TTL, the
  public origin, the anonymous acknowledgement the boot guard needs, the
  proxy's header names and the OIDC client. The role configuration and the
  session Redis are rendered beside it in the Deployment. An env list,
  unindented.
*/ -}}
{{- define "omnia.managementApi.authEnv" -}}
{{- $a := .Values.dashboard.auth }}
{{- if $a.allowAnonymous }}
# The anonymous-mode acknowledgement, without which the boot guard
# refuses an anonymous install in a cluster.
- name: OMNIA_ALLOW_ANONYMOUS
  value: "true"
{{- end }}
- name: OMNIA_SESSION_COOKIE_NAME
  value: {{ $a.cookieName | quote }}
- name: OMNIA_SESSION_TTL
  value: {{ $a.ttl | quote }}
- name: OMNIA_SESSION_PKCE_TTL
  value: {{ .Values.dashboard.session.pkceTtl | quote }}
{{- with (include "omnia.dashboard.baseUrl" .) }}
- name: OMNIA_BASE_URL
  value: {{ . | quote }}
{{- end }}
{{- include "omnia.dashboard.sessionSecretEnv" . }}
{{- if eq $a.mode "proxy" }}
{{- with .Values.dashboard.proxy }}
- name: OMNIA_AUTH_PROXY_HEADER_USER
  value: {{ .headerUser | quote }}
- name: OMNIA_AUTH_PROXY_HEADER_EMAIL
  value: {{ .headerEmail | quote }}
- name: OMNIA_AUTH_PROXY_HEADER_GROUPS
  value: {{ .headerGroups | quote }}
- name: OMNIA_AUTH_PROXY_HEADER_DISPLAY_NAME
  value: {{ .headerDisplayName | quote }}
{{- end }}
{{- end }}
{{- if eq $a.mode "oauth" }}
{{- $o := .Values.dashboard.oauth }}
- name: OMNIA_OAUTH_PROVIDER
  value: {{ $o.provider | quote }}
{{- range $name, $value := dict "OMNIA_OAUTH_ISSUER_URL" $o.issuerUrl "OMNIA_OAUTH_SCOPES" $o.scopes "OMNIA_OAUTH_AZURE_TENANT_ID" $o.azureTenantId "OMNIA_OAUTH_OKTA_DOMAIN" $o.oktaDomain }}
{{- if $value }}
- name: {{ $name }}
  value: {{ $value | quote }}
{{- end }}
{{- end }}
{{- $claims := $o.claims | default dict }}
{{- range $name, $value := dict "OMNIA_OAUTH_CLAIM_USERNAME" $claims.username "OMNIA_OAUTH_CLAIM_EMAIL" $claims.email "OMNIA_OAUTH_CLAIM_DISPLAY_NAME" $claims.displayName "OMNIA_OAUTH_CLAIM_GROUPS" $claims.groups }}
{{- if $value }}
- name: {{ $name }}
  value: {{ $value | quote }}
{{- end }}
{{- end }}
{{- include "omnia.dashboard.oauthClientEnv" . }}
{{- end }}
{{- end -}}
