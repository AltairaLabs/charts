{{/*
OpenShift's restricted-v2 SCC (#3486).

restricted-v2 admits a pod only with a runAsUser inside the UID range its
namespace was assigned, and assigns fsGroup from the namespace's supplemental
group range. Every other requirement (runAsNonRoot, no privilege escalation,
ALL capabilities dropped, RuntimeDefault seccomp, no host namespaces, paths
or ports) every chart pod already meets. So openshift.enabled changes one
thing: no chart pod pins runAsUser, runAsGroup or fsGroup, and the operator
and arena controller get --omit-pod-ids so the pods they build do not either.
*/}}

{{/* "true" when openshift.enabled, else "". */}}
{{- define "omnia.openshift" -}}
{{- if (.Values.openshift | default dict).enabled }}true{{ end -}}
{{- end }}

{{/*
omnia.podIDs renders a pod securityContext's fixed runAsUser, runAsGroup and
fsGroup, or nothing under openshift.enabled. Call with
(dict "ctx" $ "uid" 65532) and optionally "gid" and "fsGroup", which default
to uid. Indent with nindent at the securityContext's key level.
*/}}
{{- define "omnia.podIDs" -}}
{{- if not (include "omnia.openshift" .ctx) -}}
runAsUser: {{ .uid }}
runAsGroup: {{ .gid | default .uid }}
fsGroup: {{ .fsGroup | default .uid }}
{{- end -}}
{{- end }}

{{/*
omnia.withoutPodIDs returns a user-supplied pod securityContext dict with
runAsUser, runAsGroup and fsGroup removed under openshift.enabled, unchanged
otherwise. Call with (dict "ctx" $ "sc" <dict>).
*/}}
{{- define "omnia.withoutPodIDs" -}}
{{- if include "omnia.openshift" .ctx -}}
{{- toYaml (omit (.sc | default dict) "runAsUser" "runAsGroup" "fsGroup") -}}
{{- else -}}
{{- toYaml (.sc | default dict) -}}
{{- end -}}
{{- end }}

{{/*
omnia.validateOpenShift refuses what cannot run under restricted-v2 at all:
the NFS CSI driver (a privileged node plugin with hostPath mounts), an external
NFS server without it (inline nfs volumes on arena worker pods) and the
dev subchart (a privileged NFS server, a Redis pinned to uid 999, a Postgres
that starts as root). On OpenShift the storage comes from the cluster's own
RWX class instead (ODF CephFS, or an NFS provisioner the cluster admin runs).
*/}}
{{- define "omnia.validateOpenShift" -}}
{{- if include "omnia.openshift" . -}}
{{- if .Values.nfs.csiDriver.enabled -}}
{{- fail "openshift.enabled: nfs.csiDriver.enabled is not supported. The NFS CSI driver needs privileged pods and hostPath volumes, which restricted-v2 refuses. Set nfs.csiDriver.enabled=false and give workspace content an RWX storage class the cluster provides (OpenShift Data Foundation CephFS, or an NFS provisioner): workspaces.storage.storageClass." -}}
{{- end -}}
{{- if and .Values.nfs.external.server (not .Values.nfs.csiDriver.enabled) -}}
{{- fail "openshift.enabled: nfs.external.server is not supported without a CSI driver. arena-controller then mounts the share as an inline nfs volume on every arena worker pod, and restricted-v2 refuses the nfs volume type. Expose the share through a StorageClass the cluster provides and set workspaces.storage.storageClass instead." -}}
{{- end -}}
{{- if .Values.dev.enabled -}}
{{- fail "openshift.enabled: dev.enabled is not supported. The development subchart runs a privileged NFS server, a Redis pinned to uid 999 and a Postgres that starts as root, none of which restricted-v2 admits. Use a Postgres and Redis provisioned outside the chart." -}}
{{- end -}}
{{- end -}}
{{- end }}
