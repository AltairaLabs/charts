{{/*
The dashboard's shared /_next/static/ store (#2303). Off by default; with
dashboard.staticAssets.persistence.enabled every dashboard pod publishes its
build into one volume and serves earlier builds' chunks from it, so a tab
loaded before an upgrade keeps working through and after the rollout.
*/}}

{{/* "true" when the store is on (and the dashboard is), else "". */}}
{{- define "omnia.dashboard.staticStore.enabled" -}}
{{- $sa := .Values.dashboard.staticAssets | default dict -}}
{{- $p := $sa.persistence | default dict -}}
{{- if and .Values.dashboard.enabled $p.enabled }}true{{ end -}}
{{- end }}

{{/* Where both containers mount the store. Structural: nothing else reads it. */}}
{{- define "omnia.dashboard.staticStore.path" -}}
/var/lib/omnia/static-store
{{- end }}

{{/* The claim the store lives on: an existing one, or the chart's. */}}
{{- define "omnia.dashboard.staticStore.claimName" -}}
{{- .Values.dashboard.staticAssets.persistence.existingClaim | default (printf "%s-static-assets" (include "omnia.dashboard.fullname" .)) -}}
{{- end }}

{{/* "true" when the store's declared access modes let pods on several nodes mount it. */}}
{{- define "omnia.dashboard.staticStore.rwx" -}}
{{- if has "ReadWriteMany" (.Values.dashboard.staticAssets.persistence.accessModes | default list) }}true{{ end -}}
{{- end }}

{{/*
The Deployment's update strategy, as YAML, or empty for Kubernetes' default
(RollingUpdate):

  - dashboard.updateStrategy, when set, always.
  - Recreate when the store is on and its access modes do not include
    ReadWriteMany. A ReadWriteOnce volume attaches to one node, so a rolling
    update's new pod, scheduled elsewhere, waits for the old pod's volume
    while the old pod waits for the new one to be ready, and the rollout
    stalls. Recreate stops the old pod first. The store already holds the
    old build (that pod published it when it started), so tabs loaded from
    it keep their chunks once the new pod is up. Set dashboard.updateStrategy
    to RollingUpdate yourself where the volume can attach to both pods at
    once (a single-node cluster, a ReadWriteOnce driver that allows it).
*/}}
{{- define "omnia.dashboard.updateStrategy" -}}
{{- if .Values.dashboard.updateStrategy -}}
{{- toYaml .Values.dashboard.updateStrategy -}}
{{- else if and (include "omnia.dashboard.staticStore.enabled" .) (not (include "omnia.dashboard.staticStore.rwx" .)) -}}
type: Recreate
{{- end -}}
{{- end }}

{{/*
Render-time guard: more than one dashboard replica sharing the store needs
ReadWriteMany, because the replicas run on different nodes and every one
mounts it.
*/}}
{{- define "omnia.dashboard.validateStaticAssets" -}}
{{- if and (include "omnia.dashboard.staticStore.enabled" .) (gt (int .Values.dashboard.replicaCount) 1) (not (include "omnia.dashboard.staticStore.rwx" .)) -}}
{{- fail (printf "dashboard.staticAssets.persistence with dashboard.replicaCount=%d needs accessModes [ReadWriteMany]: every replica mounts the store, on whichever node it runs. Use a ReadWriteMany storage class, or one replica (#2303)." (int .Values.dashboard.replicaCount)) -}}
{{- end -}}
{{- end }}
