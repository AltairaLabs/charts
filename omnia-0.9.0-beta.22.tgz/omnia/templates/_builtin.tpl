{{/*
The builtin sign-in's settings, as env entries (#2632). management-api serves
builtin sign-in and owns the users, so it is given all of them; the dashboard
reads only the signup switch and the minimum password length from its
ConfigMap, to render its forms.
*/}}

{{/*
omnia.dashboard.baseUrl is the dashboard's public address: dashboard.baseUrl,
else derived from its ingress when enabled; empty otherwise (both tiers then
fall back to http://localhost:3000).
*/}}
{{- define "omnia.dashboard.baseUrl" -}}
{{- if .Values.dashboard.baseUrl -}}
{{- .Values.dashboard.baseUrl -}}
{{- else if .Values.dashboard.ingress.enabled -}}
{{- $scheme := "http" -}}
{{- if .Values.dashboard.ingress.tls -}}
{{- $scheme = "https" -}}
{{- end -}}
{{- printf "%s://%s" $scheme .Values.dashboard.ingress.host -}}
{{- end -}}
{{- end -}}

{{/*
omnia.builtin.smtpEnv is OMNIA_SMTP_* from dashboard.builtin.smtp, for the
password-reset and verification emails management-api sends; nothing when no host is set (the
emails are then not sent, and a warning is logged). The password comes only
from a Secret.
*/}}
{{- define "omnia.builtin.smtpEnv" -}}
{{- $smtp := .Values.dashboard.builtin.smtp | default dict -}}
{{- if $smtp.host -}}
- name: OMNIA_SMTP_HOST
  value: {{ $smtp.host | quote }}
- name: OMNIA_SMTP_PORT
  value: {{ $smtp.port | quote }}
- name: OMNIA_SMTP_SECURE
  value: {{ $smtp.secure | quote }}
- name: OMNIA_SMTP_FROM
  value: {{ $smtp.from | quote }}
{{- with $smtp.user }}
- name: OMNIA_SMTP_USER
  value: {{ . | quote }}
{{- end }}
{{- with $smtp.existingSecret }}
- name: OMNIA_SMTP_PASS
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: OMNIA_SMTP_PASS
{{- end }}
{{- end -}}
{{- end -}}

{{/*
omnia.builtin.managementApiEnv is everything management-api's builtin
sign-in routes read beyond omnia.managementApi.authEnv (the session and the
base URL every emailed link starts with): the dashboard's builtin settings,
the seeded admin and the email settings. Builtin mode only.
*/}}
{{- define "omnia.builtin.managementApiEnv" -}}
{{- if eq .Values.dashboard.auth.mode "builtin" -}}
{{- $b := .Values.dashboard.builtin -}}
- name: OMNIA_BUILTIN_ALLOW_SIGNUP
  value: {{ $b.allowSignup | quote }}
- name: OMNIA_BUILTIN_VERIFY_EMAIL
  value: {{ $b.verifyEmail | quote }}
- name: OMNIA_BUILTIN_MIN_PASSWORD_LENGTH
  value: {{ $b.minPasswordLength | quote }}
- name: OMNIA_BUILTIN_MAX_FAILED_ATTEMPTS
  value: {{ $b.maxFailedAttempts | quote }}
- name: OMNIA_BUILTIN_LOCKOUT_DURATION
  value: {{ $b.lockoutDuration | quote }}
- name: OMNIA_BUILTIN_ADMIN_USERNAME
  value: {{ $b.admin.username | quote }}
- name: OMNIA_BUILTIN_ADMIN_EMAIL
  value: {{ $b.admin.email | quote }}
{{- if $b.admin.existingSecret }}
- name: OMNIA_BUILTIN_ADMIN_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ $b.admin.existingSecret }}
      key: OMNIA_BUILTIN_ADMIN_PASSWORD
{{- else if $b.admin.password }}
- name: OMNIA_BUILTIN_ADMIN_PASSWORD
  value: {{ $b.admin.password | quote }}
{{- end }}
{{- with (include "omnia.builtin.smtpEnv" .) }}
{{ . }}
{{- end }}
{{- end -}}
{{- end -}}
