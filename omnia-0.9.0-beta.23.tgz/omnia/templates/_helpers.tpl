{{/*
Auth-mode guardrails — emits nothing but fails `helm template|install|upgrade`
when the deployment would silently run unauthenticated.

Rules:
  - dashboard.auth.mode MUST be explicitly set when dashboard.enabled=true.
    (The chart no longer has a safe default — you have to choose.)
  - Only oauth / builtin / proxy / anonymous are accepted.
  - mode=anonymous additionally requires dashboard.auth.allowAnonymous=true
    as an explicit acknowledgement. Anonymous mode disables authentication
    entirely and is intended for isolated development only.

Include this from every template that renders when dashboard.enabled=true
so the render aborts early on misconfiguration.
*/}}
{{- define "omnia.validateAuth" -}}
{{- if .Values.dashboard.enabled -}}
{{- $mode := required "dashboard.auth.mode must be set explicitly to one of: oauth, builtin, proxy, anonymous" .Values.dashboard.auth.mode -}}
{{- $validModes := list "oauth" "builtin" "proxy" "anonymous" -}}
{{- if not (has $mode $validModes) -}}
{{- fail (printf "dashboard.auth.mode=%q is not valid. Must be one of: oauth, builtin, proxy, anonymous" $mode) -}}
{{- end -}}
{{- if eq $mode "anonymous" -}}
{{- if not .Values.dashboard.auth.allowAnonymous -}}
{{- fail "dashboard.auth.mode=\"anonymous\" disables authentication entirely. Set dashboard.auth.allowAnonymous=true to acknowledge this is intentional. Anonymous mode is intended for isolated development only." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "omnia.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "omnia.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "omnia.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "omnia.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "omnia.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
control-plane: controller-manager
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "omnia.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "omnia.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
arena-controller's ServiceAccount (#2919): its own, never the operator's.
*/}}
{{- define "omnia.arenaController.serviceAccountName" -}}
{{- $sa := .Values.enterprise.arena.controller.serviceAccount | default dict }}
{{- if ne $sa.create false }}
{{- default (printf "%s-arena-controller" (include "omnia.fullname" .)) $sa.name }}
{{- else }}
{{- default "default" $sa.name }}
{{- end }}
{{- end }}

{{/*
PromptKit LSP's ServiceAccount (#2919): its own, never the operator's.
*/}}
{{- define "omnia.promptkitLsp.serviceAccountName" -}}
{{- $sa := .Values.enterprise.promptkitLsp.serviceAccount | default dict }}
{{- if ne $sa.create false }}
{{- default (printf "%s-promptkit-lsp" (include "omnia.fullname" .)) $sa.name }}
{{- else }}
{{- default "default" $sa.name }}
{{- end }}
{{- end }}

{{/*
The ServiceAccount the operator's pod runs as — podOverrides.serviceAccountName
replaces the chart's, exactly as templates/deployment.yaml applies it.
*/}}
{{- define "omnia.operatorServiceAccountName" -}}
{{- $po := .Values.operator.podOverrides | default dict }}
{{- $po.serviceAccountName | default (include "omnia.serviceAccountName" .) }}
{{- end }}

{{/*
The username the API server authenticates the operator's pod as. The sandbox
claim admission policy exempts exactly this identity, and the operator checks
the live policy exempts exactly it (--sandbox-claim-policy-operator-user).
*/}}
{{- define "omnia.operatorUsername" -}}
{{- printf "system:serviceaccount:%s:%s" .Release.Namespace (include "omnia.operatorServiceAccountName" .) }}
{{- end }}

{{/*
The spec of the ValidatingAdmissionPolicy that admits a privileged
SandboxClaim only from the operator (templates/sandbox-claim-policy.yaml).
*/}}
{{- define "omnia.sandboxClaimPolicySpec" -}}
# Fail, not Ignore: the operator refuses privileged claims under a policy
# that does not fail closed.
failurePolicy: Fail
matchConstraints:
  resourceRules:
    - apiGroups: ["omnia.altairalabs.ai"]
      apiVersions: ["*"]
      operations: ["CREATE", "UPDATE"]
      resources: ["sandboxclaims"]
matchConditions:
  # The operator's own writes are the ones this policy exists to allow.
  - name: not-the-operator
    expression: "request.userInfo.username != '{{ include "omnia.operatorUsername" . }}'"
{{ .Files.Get "files/sandbox-claim-policy.yaml" }}
{{- end }}

{{/*
Name of that policy and of its binding. It carries a hash of the policy's
spec, so a change to the rules is a NEW policy rather than an edit to the old
one: the operator honours a policy only at metadata.generation 1, dating it
from its creation (internal/sandboxprovenance).
*/}}
{{- define "omnia.sandboxClaimPolicyName" -}}
{{- $base := printf "%s-sandbox-claim" (include "omnia.fullname" .) | trunc 54 | trimSuffix "-" }}
{{- /* Hashed as parsed YAML, so a comment edit is not a new policy. */}}
{{- printf "%s-%s" $base (include "omnia.sandboxClaimPolicySpec" . | fromYaml | toJson | sha256sum | trunc 8) }}
{{- end }}

{{/*
Development mode — DERIVED, never configured directly.

Omnia has exactly three licensing states:

  Core      enterprise.enabled=false            enterprise features absent
  Dev mode  enterprise.enabled=true, no licence every feature on, banner on
  Licensed  enterprise.enabled=true + licence   every feature on, silent

"Enterprise installed but unlicensed" is not a fourth state — it IS dev mode.
So dev mode is not something you switch on; it is what you get when you ask for
Enterprise and supply no licence. There is no separate `devMode` value, because
two independent switches could disagree and only one of them was ever the truth.

Renders "true" or "" (falsey to `if`).

Escape hatch: a licence Secret created out of band — GitOps, sealed-secrets, an
operator applying `arena-license` by hand — appears in neither `license.key` nor
`license.existingSecret`, so such an install would derive dev mode and nag while
genuinely licensed. Set `license.externallyManaged: true` for that case.
*/}}
{{- define "omnia.devMode" -}}
{{- if and .Values.enterprise.enabled (not .Values.license.key) (not .Values.license.existingSecret) (not .Values.license.externallyManaged) -}}
true
{{- end -}}
{{- end }}

{{/*
omnia.registryImage rewrites one image reference onto global.imageRegistry
(#3483). Called with (dict "ctx" $ "image" "<repository>:<tag>").

The registry HOST is replaced and everything after it kept, so a mirror holds
each image at the same path it has upstream:

  ghcr.io/altairalabs/omnia-operator:1.0  ->  <registry>/altairalabs/omnia-operator:1.0
  busybox:1.36                            ->  <registry>/busybox:1.36

The first path segment is a host when it holds a "." or a ":" or is
"localhost" (Docker's own rule), so a Docker Hub name (busybox,
pgvector/pgvector) has no host to strip and is prefixed whole. A reference
already under the registry is left alone. hack/mirror.sh applies the same rule
when it pushes, and hack/airgap-bundle_test.sh holds it to the same cases as
tests/global-image-registry_test.yaml.

Every image the chart renders, and every image flag it passes the operator,
goes through here; tests/global-image-registry_test.yaml fails on one that
does not.
*/}}
{{- define "omnia.registryImage" -}}
{{- $ref := .image -}}
{{- $reg := trimSuffix "/" (toString ((.ctx.Values.global | default dict).imageRegistry | default "")) -}}
{{- if and $reg (not (hasPrefix (printf "%s/" $reg) $ref)) -}}
{{- $parts := splitList "/" $ref -}}
{{- $first := first $parts -}}
{{- if and (gt (len $parts) 1) (or (contains "." $first) (contains ":" $first) (eq $first "localhost")) -}}
{{- $ref = join "/" (rest $parts) -}}
{{- end -}}
{{- printf "%s/%s" $reg $ref -}}
{{- else -}}
{{- $ref -}}
{{- end -}}
{{- end }}

{{/*
omnia.imageRef builds "<repository>:<tag>" from an image values block, the tag
defaulting to the chart's appVersion, and puts it on global.imageRegistry.
Called with (dict "ctx" $ "image" .Values.<component>.image). A block with a
`digest` renders "<repository>@<digest>" instead: the Azure marketplace variant
pins every image that way (marketplace/azure-images.py --digests).
*/}}
{{- define "omnia.imageRef" -}}
{{- if .image.digest -}}
{{- include "omnia.registryImage" (dict "ctx" .ctx "image" (printf "%s@%s" .image.repository .image.digest)) -}}
{{- else -}}
{{- $tag := .image.tag | default .ctx.Chart.AppVersion -}}
{{- include "omnia.registryImage" (dict "ctx" .ctx "image" (printf "%s:%s" .image.repository $tag)) -}}
{{- end -}}
{{- end }}

{{/*
omnia.pullSecretNames is the de-duplicated list of Secret names in a list of
imagePullSecrets entries, as JSON (fromJsonArray reads it back). An entry may
be a bare name or a {name: ...} map: global.imagePullSecrets is shared with
the observability subcharts, and upstream charts accept both shapes.
*/}}
{{- define "omnia.pullSecretNames" -}}
{{- $names := list -}}
{{- range . -}}
{{- $n := "" -}}
{{- if kindIs "string" . -}}
{{- $n = . -}}
{{- else if kindIs "map" . -}}
{{- $n = get . "name" -}}
{{- end -}}
{{- if and $n (not (has $n $names)) -}}
{{- $names = append $names $n -}}
{{- end -}}
{{- end -}}
{{- toJson $names -}}
{{- end }}

{{/*
omnia.imagePullSecrets renders a pod's imagePullSecrets block: the chart-wide
global.imagePullSecrets and imagePullSecrets, then the component's own (a
podOverrides list), each name once. Renders nothing for an empty list.
Called with (dict "ctx" $ "extra" $po.imagePullSecrets) inside a `with`, so an
empty list leaves no blank line:

  {{- with include "omnia.imagePullSecrets" (dict "ctx" . "extra" $po.imagePullSecrets) }}
  {{- . | nindent 6 }}
  {{- end }}
*/}}
{{- define "omnia.imagePullSecrets" -}}
{{- $global := (.ctx.Values.global | default dict).imagePullSecrets | default list -}}
{{- $all := concat $global (.ctx.Values.imagePullSecrets | default list) (.extra | default list) -}}
{{- $names := include "omnia.pullSecretNames" $all | fromJsonArray -}}
{{- if $names -}}
imagePullSecrets:
{{- range $names }}
  - name: {{ . }}
{{- end }}
{{- end -}}
{{- end }}

{{/*
omnia.priorityClass is the name of one scheduling tier (#3586) — "interactive"
or "batch", passed as .tier — or "" when the tiers are off. The operator gives
the interactive class to agents and sandboxes; the arena controller gives the
batch class to its workers.
*/}}
{{- define "omnia.priorityClass" -}}
{{- $pc := .ctx.Values.scheduling.priorityClasses -}}
{{- if $pc.enabled -}}
{{- $tier := index $pc .tier -}}
{{- required (printf "scheduling.priorityClasses.%s.name is required when scheduling.priorityClasses.enabled" .tier) $tier.name -}}
{{- end -}}
{{- end }}

{{/*
omnia.operatorImagePullSecrets is the comma-separated global.imagePullSecrets
names the operator and arena-controller prepend to every pod THEY create. Only
the global list travels: the chart-wide imagePullSecrets has only ever applied
to the chart's own pods, and a Secret named here must exist in every workspace
namespace, which an install that set it for the operator's namespace alone
never arranged.
*/}}
{{- define "omnia.operatorImagePullSecrets" -}}
{{- $global := (.Values.global | default dict).imagePullSecrets | default list -}}
{{- join "," (include "omnia.pullSecretNames" $global | fromJsonArray) -}}
{{- end }}

{{/*
Manager image
*/}}
{{- define "omnia.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.image) }}
{{- end }}

{{/*
Dashboard fullname
*/}}
{{- define "omnia.dashboard.fullname" -}}
{{- printf "%s-dashboard" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Dashboard labels
*/}}
{{- define "omnia.dashboard.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.dashboard.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Dashboard selector labels
*/}}
{{- define "omnia.dashboard.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-dashboard
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: dashboard
{{- end }}

{{/*
Dashboard image
*/}}
{{- define "omnia.dashboard.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.dashboard.image) }}
{{- end }}

{{/*
Dashboard service account name.

The dashboard has its own ServiceAccount, with no RBAC and no mounted token
(#2634: it is nginx serving static files), so its pod never runs as the
namespace's default ServiceAccount or the operator's.

Lookup order:
  1. .Values.dashboard.serviceAccount.name (explicit override)
  2. Computed: "<release>-dashboard"
  3. "default" when dashboard.serviceAccount.create=false and no name set.
*/}}
{{- define "omnia.dashboard.serviceAccountName" -}}
{{- if .Values.dashboard.serviceAccount.create }}
{{- default (include "omnia.dashboard.fullname" .) .Values.dashboard.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.dashboard.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
The ServiceAccount the dashboard's pod runs as — podOverrides.serviceAccountName
replaces the chart's, exactly as templates/dashboard/deployment.yaml applies it.
Nothing trusts it: the pod mounts no token and the chart names it in no
allowlist or grant (#2634).
*/}}
{{- define "omnia.dashboard.podServiceAccountName" -}}
{{- $po := .Values.dashboard.podOverrides | default dict }}
{{- $po.serviceAccountName | default (include "omnia.dashboard.serviceAccountName" .) }}
{{- end }}

{{/*
omnia.toolTest.bindAddress — operator tool-test API bind address.
Explicit operator.apiBindAddress wins; otherwise defaults to ":8083" when the
dashboard is enabled (its only consumer is management-api, deployed with the
dashboard). Empty disables the API entirely.
*/}}
{{- define "omnia.toolTest.bindAddress" -}}
{{- if .Values.operator.apiBindAddress -}}
{{- .Values.operator.apiBindAddress -}}
{{- else if .Values.dashboard.enabled -}}
:8083
{{- end -}}
{{- end -}}

{{/*
omnia.contentApi.bindAddress — operator workspace-content API bind address.
management-api reads/writes workspace content for the dashboard through this
authenticated operator endpoint instead of mounting the NFS volume (#1462).
Needs the dashboard (management-api, deployed with it, mints the identity JWT
the operator verifies via JWKS); the
operator always mounts the workspace-content share root and has a content path.
Explicit workspaceContent.contentApi.bindAddress wins; defaults to ":8084".
Empty disables it.
*/}}
{{- define "omnia.contentApi.bindAddress" -}}
{{- $ca := .Values.workspaceContent.contentApi | default dict -}}
{{- if and .Values.dashboard.enabled $ca.enabled -}}
{{- $ca.bindAddress | default ":8084" -}}
{{- end -}}
{{- end -}}

{{/*
omnia.deployApi.bindAddress — operator deploy-intent API bind address.
management-api forwards DeployIntent bodies to this authenticated operator
endpoint, which verifies the management-api-minted identity JWT (via
--mgmt-plane-jwks-url, already emitted unconditionally when the dashboard
is enabled) and applies the resulting spec. Explicit
workspaceContent.deployApi.bindAddress wins; defaults to ":8085". NOT ":8083"
-- omnia.toolTest.bindAddress (above) ALSO defaults to ":8083" whenever
dashboard.enabled is true (the chart's own default), so ":8083" here would
collide with the tool-test API on the same operator process and crash-loop
it on any default install. Empty disables the deploy API.
*/}}
{{- define "omnia.deployApi.bindAddress" -}}
{{- $da := .Values.workspaceContent.deployApi | default dict -}}
{{- if and .Values.dashboard.enabled $da.enabled -}}
{{- $da.bindAddress | default ":8085" -}}
{{- end -}}
{{- end -}}

{{/*
Compaction image
*/}}
{{- define "omnia.compaction.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.sessionRetention.compaction.image) }}
{{- end }}

{{/*
PromptKit LSP image.

Every image reference belongs in one helper reading one values path. The LSP's
was inlined in its Deployment with a `default "ghcr.io/..."` fallback that could
never fire — values.yaml already sets the repository — so the literal was dead
code shadowing the configured value, and a registry rewrite would have missed it.
*/}}
{{- define "omnia.promptkitLsp.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.enterprise.promptkitLsp.image) }}
{{- end }}

{{/*
Image used by the chart's `helm test` hooks.

Parameterised for the same reason: a hardcoded `busybox:1.36` is unreachable in
an air-gapped install and invisible to any tooling that rewrites registries.
*/}}
{{- define "omnia.test.image" -}}
{{- include "omnia.registryImage" (dict "ctx" . "image" (printf "%s:%s" .Values.tests.image.repository .Values.tests.image.tag)) }}
{{- end }}

{{/*
Session API image.

Only the IMAGE, deliberately. session-api is not a chart-owned workload: the
operator creates one per service group, so its name, labels and selector are
the operator's business. The chart's job is to tell the operator which image to
use. The fullname/labels/selectorLabels helpers that used to sit here were left
behind by that move and were included by nothing.
*/}}
{{- define "omnia.sessionApi.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.workspaceServices.sessionApi.image) }}
{{- end }}

{{/*
Memory API image. Operator-managed, same as session-api above.
*/}}
{{- define "omnia.memoryApi.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.workspaceServices.memoryApi.image) }}
{{- end }}

{{/*
Workspace Eval Worker image (operator-managed per-service-group worker)
*/}}
{{- define "omnia.workspaceEvalWorker.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.workspaceServices.evalWorker.image) }}
{{- end }}

{{/*
Privacy API image (operator-managed per-workspace service)
*/}}
{{- define "omnia.privacyApi.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.workspaceServices.privacyApi.image) }}
{{- end }}

{{/*
Doctor fullname
*/}}
{{- define "omnia.doctor.fullname" -}}
{{- printf "%s-doctor" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Doctor labels
*/}}
{{- define "omnia.doctor.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.doctor.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Doctor selector labels
*/}}
{{- define "omnia.doctor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-doctor
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: doctor
{{- end }}

{{/*
Doctor image
*/}}
{{- define "omnia.doctor.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.doctor.image) }}
{{- end }}

{{/*
management-api fullname (#2626)
*/}}
{{- define "omnia.managementApi.fullname" -}}
{{- printf "%s-management-api" (include "omnia.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
management-api labels
*/}}
{{- define "omnia.managementApi.labels" -}}
helm.sh/chart: {{ include "omnia.chart" . }}
{{ include "omnia.managementApi.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
management-api selector labels
*/}}
{{- define "omnia.managementApi.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-management-api
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: management-api
{{- end }}

{{/*
Whether management-api is deployed: managementApi.enabled, and only with the
dashboard. It serves the dashboard's whole /api surface (#2634), and the
dashboard refuses to render without it. Every template asks this, never
managementApi.enabled directly, so the allowlists, mounts and env the operator
and other components carry for it agree with whether it exists. Empty for
false.
*/}}
{{- define "omnia.managementApi.enabled" -}}
{{- if and .Values.managementApi.enabled .Values.dashboard.enabled }}true{{ end }}
{{- end }}

{{/*
The Prometheus the dashboard's views query, through management-api's proxy
routes: dashboard.prometheus.url, else the
bundled server when prometheus.enabled, else empty (Prometheus is optional; an
empty URL answers "Prometheus not configured"). The bundled server is served
under server.prefixURL (default /prometheus), so its API lives at
<prefix>/api/v1/... — the prefix is included or every query 404s. Read by the
dashboard ConfigMap's PROMETHEUS_URL and by management-api's own, both of which
management-api reads (#2631), so the two cannot disagree.
*/}}
{{- define "omnia.prometheusUrl" -}}
{{- if .Values.dashboard.prometheus.url -}}
{{ .Values.dashboard.prometheus.url }}
{{- else if .Values.prometheus.enabled -}}
http://{{ .Release.Name }}-prometheus-server:80{{ .Values.prometheus.server.prefixURL | default "" }}
{{- end -}}
{{- end }}

{{/*
The PromptKit LSP's WebSocket URL in this release's namespace, when the LSP
server is enabled, else empty. management-api's WebSocket proxy (#2631)
dials it for /api/v1/lsp; without it, it falls back to a hard-coded
omnia-system namespace that resolves only when the release lives there.
*/}}
{{- define "omnia.promptkitLsp.url" -}}
{{- if and .Values.enterprise.enabled .Values.enterprise.promptkitLsp.enabled -}}
ws://{{ include "omnia.fullname" . }}-promptkit-lsp.{{ .Release.Namespace }}.svc.cluster.local:{{ .Values.enterprise.promptkitLsp.service.port | default 8080 }}/lsp
{{- end -}}
{{- end }}

{{/*
management-api's ServiceAccount, honouring podOverrides.serviceAccountName.
*/}}
{{/*
The E2B sandbox gateway's ServiceAccount (#3603).
*/}}
{{- define "omnia.sandboxGateway.serviceAccountName" -}}
{{- $sa := .Values.enterprise.sandboxGateway.serviceAccount | default dict }}
{{- if ne $sa.create false }}
{{- default (printf "%s-sandbox-gateway" (include "omnia.fullname" .)) $sa.name }}
{{- else }}
{{- default "default" $sa.name }}
{{- end }}
{{- end }}

{{/*
The E2B sandbox gateway's pod labels. Its own, with no control-plane label,
so no other Service or Deployment of the chart selects its pods. The operator
is told them (--e2b-gateway-pod-labels): an E2B sandbox's NetworkPolicy admits
exactly these pods, from the install namespace.
*/}}
{{- define "omnia.sandboxGateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "omnia.name" . }}-sandbox-gateway
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: sandbox-gateway
{{- end }}

{{- define "omnia.sandboxGateway.enabled" -}}
{{- if and .Values.enterprise.enabled .Values.enterprise.sandboxGateway.enabled }}true{{- end }}
{{- end }}

{{- define "omnia.managementApi.serviceAccountName" -}}
{{- $po := .Values.managementApi.podOverrides | default dict }}
{{- $po.serviceAccountName | default (include "omnia.managementApi.fullname" .) }}
{{- end }}

{{/*
management-api's ServiceAccount as a TokenReview subject, for the allowlists
of the services it calls (#2627).
*/}}
{{- define "omnia.managementApi.subject" -}}
system:serviceaccount:{{ .Release.Namespace }}:{{ include "omnia.managementApi.serviceAccountName" . }}
{{- end }}

{{/*
The Secret holding management-api's signing keypair.
*/}}
{{- define "omnia.managementApi.signingKeySecret" -}}
{{- .Values.managementApi.signingKey.existingSecret | default (printf "%s-signing-keypair" (include "omnia.managementApi.fullname" .)) }}
{{- end }}

{{/*
The database management-api's API-key store reads when it is the postgres
store (#2632), as a name: "apiKeys" (dashboard.apiKeys.postgresUrl or
existingPostgresSecret), else, in builtin mode, "builtin"
(dashboard.builtin.postgresUrl or existingPostgresSecret), else "management"
(managementApi.database). The first two are the stores the Node-era dashboard
used, so the keys already minted keep working; only when neither is set does management-api
keep keys in its own database. Empty when API keys are off or the store is not
postgres.
*/}}
{{- define "omnia.managementApi.apiKeysDatabase" -}}
{{- $ak := .Values.dashboard.apiKeys -}}
{{- $b := .Values.dashboard.builtin -}}
{{- if and $ak.enabled (eq (include "omnia.dashboard.apiKeyStore" .) "postgres") -}}
{{- if or $ak.postgresUrl $ak.existingPostgresSecret -}}
apiKeys
{{- else if and (eq .Values.dashboard.auth.mode "builtin") (or $b.postgresUrl $b.existingPostgresSecret) -}}
builtin
{{- else -}}
management
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: management-api needs its own database
(managementApi.database.existingSecret) wherever it would keep anything in it:
a postgres API-key store with no other database to read (#2632). Builtin
users are the other thing it keeps there; omnia.managementApi.validateSignIn
requires the database in builtin mode.
*/}}
{{- define "omnia.managementApi.validateDatabase" -}}
{{- if not .Values.managementApi.database.existingSecret -}}
{{- if eq (include "omnia.managementApi.apiKeysDatabase" .) "management" -}}
{{- fail "dashboard.apiKeys.store=postgres with no dashboard.apiKeys.postgresUrl/existingPostgresSecret requires managementApi.database.existingSecret (a Secret with a POSTGRES_CONN key) to keep the keys in." -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard for sign-in (#2632): in builtin mode, management-api's own
database, where builtin users live — without it management-api has no user to
sign in. This is the builtin half of omnia.managementApi.validateDatabase.

management-api is the one reader of the sessions it writes (#2634), so a
single replica keeps them in memory; more than one needs Redis, which
omnia.validateSession checks.
*/}}
{{- define "omnia.managementApi.validateSignIn" -}}
{{- $mode := .Values.dashboard.auth.mode -}}
{{- if and (eq $mode "builtin") (not .Values.managementApi.database.existingSecret) -}}
{{- fail "dashboard.auth.mode=builtin requires managementApi.database.existingSecret (a Secret with a POSTGRES_CONN key): management-api keeps builtin users in its own database." -}}
{{- end -}}
{{- end }}

{{/*
The URL of a management-plane trust endpoint (#2632 5-11): the JWKS the
operator hands the facades (`jwks`), or the service-token mint Doctor and the
Arena workers exchange their ServiceAccount token at (`service-token`).
Always management-api's (/api/v1/auth/<path>): nothing else serves either
endpoint since the dashboard's Node tier went (#2634). Every caller renders
it only with the dashboard enabled, and the dashboard refuses to render
without management-api serving the keys (omnia.managementApi.servesKeys), so
the fail below is a safety net for a new caller that forgets that gate: it
used to fall back to the dashboard Service's /api/auth/<path>, a URL that
renders cleanly and 404s at runtime. Callers apply their own explicit
override (dashboard.jwksUrl and the like) first.

management-api's JWKS holds its own signing key
(management-api/signing-keypair.yaml) and any
managementApi.signingKey.additionalCertSecrets; the dashboard signs nothing
(#2634).

Takes (dict "ctx" . "path" "jwks"|"service-token").
*/}}
{{- define "omnia.mgmtPlane.url" -}}
{{- $ctx := .ctx -}}
{{- if include "omnia.managementApi.servesKeys" $ctx -}}
{{- printf "http://%s.%s.svc.cluster.local:%d/api/v1/auth/%s" (include "omnia.managementApi.fullname" $ctx) $ctx.Release.Namespace (int $ctx.Values.managementApi.service.port) .path -}}
{{- else -}}
{{- fail (printf "the management-plane %s endpoint is management-api's alone (#2634): it needs dashboard.enabled, managementApi.enabled and managementApi.servesManagementPlaneKeys all true, or an explicit URL (dashboard.jwksUrl, dashboard.serviceTokenUrl, doctor.mgmtPlaneToken.url)" .path) -}}
{{- end -}}
{{- end }}

{{/*
The ServiceAccounts permitted to mint management-plane tokens at the
service-token endpoint, as OMNIA_DASHBOARD_SERVICE_TOKEN_ALLOWED_SAS takes them
(comma-separated <namespace>/<name>): dashboard.serviceTokenAllowlist, plus
Doctor's when it is on, and arena-controller's under Enterprise. management-api serves the endpoint (#2632); the
dashboard does not. Empty when nobody is listed.
*/}}
{{- define "omnia.serviceTokenAllowedSAs" -}}
{{- $sas := .Values.dashboard.serviceTokenAllowlist | default (list) }}
{{- /* Not `default true .enabled`: default treats false as unset, so
       doctor.mgmtPlaneToken.enabled=false used to list Doctor anyway (#3806). */}}
{{- $doctorToken := .Values.doctor.mgmtPlaneToken | default dict }}
{{- if and .Values.doctor.enabled (ternary $doctorToken.enabled true (hasKey $doctorToken "enabled")) }}
{{- $sas = append $sas (printf "%s/%s" .Release.Namespace (include "omnia.doctor.fullname" .)) }}
{{- end }}
{{- /* arena-controller reaches each service group's Dreaming compiler on its
       management-plane twin with a token minted here (#2511). */}}
{{- if .Values.enterprise.enabled }}
{{- $sas = append $sas (printf "%s/%s" .Release.Namespace (include "omnia.arenaController.serviceAccountName" .)) }}
{{- end }}
{{- join "," $sas }}
{{- end }}

{{/*
management-api image
*/}}
{{- define "omnia.managementApi.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.managementApi.image) }}
{{- end }}

{{/*
Images the operator and arena-controller run on the chart's behalf. Each is
passed as a flag, so the pods the operator creates follow global.imageRegistry
exactly as the chart's own do. The chart always passes them: the binaries'
compiled-in defaults name ghcr.io and are for a bare `make run` only.
*/}}
{{- define "omnia.facade.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.facade.image) }}
{{- end }}

{{- define "omnia.framework.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.framework.image) }}
{{- end }}

{{- define "omnia.policyBroker.image" -}}
{{- include "omnia.imageRef" (dict "ctx" . "image" .Values.enterprise.policyBroker.image) }}
{{- end }}

{{- define "omnia.arenaController.image" -}}
{{- $img := .Values.enterprise.arena.controller.image }}
{{- include "omnia.imageRef" (dict "ctx" . "image" (dict "repository" ($img.repository | default "ghcr.io/altairalabs/omnia-arena-controller") "tag" $img.tag "digest" $img.digest)) }}
{{- end }}

{{- define "omnia.arenaWorker.image" -}}
{{- $img := .Values.enterprise.arena.worker.image }}
{{- include "omnia.imageRef" (dict "ctx" . "image" (dict "repository" ($img.repository | default "ghcr.io/altairalabs/omnia-arena-worker") "tag" $img.tag "digest" $img.digest)) }}
{{- end }}


{{/*
Walk a dotted path into .Values and return the resolved sub-value, or
an empty dict if any segment is missing. Internal helper.
*/}}
{{- define "omnia.redis._lookupConsumer" -}}
{{- $ctx := .ctx -}}
{{- $path := .consumer -}}
{{- $node := $ctx.Values -}}
{{- if $path -}}
  {{- range $part := splitList "." $path -}}
    {{- if and (kindIs "map" $node) (hasKey $node $part) -}}
      {{- $node = index $node $part -}}
    {{- else -}}
      {{- $node = dict -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- toYaml $node -}}
{{- end }}

{{/*
Resolve the existingSecret reference for a given consumer's Redis URL.

Args (dict):
  ctx      - the root context ($)
  consumer - dotted path to the per-consumer Redis block.

Returns the resolved {name, key} dict from consumer.existingSecret
(preferred) or redis.default.existingSecret (fallback). Returns an
empty dict when neither has one. Internal helper for the public
omnia.redis.* family.
*/}}
{{- define "omnia.redis._existingSecret" -}}
{{- $consumer := fromYaml (include "omnia.redis._lookupConsumer" .) -}}
{{- $default := .ctx.Values.redis.default | default dict -}}
{{- $secret := dict -}}
{{- if and (kindIs "map" $consumer) (kindIs "map" $consumer.existingSecret) (default "" $consumer.existingSecret.name) (default "" $consumer.existingSecret.key) -}}
  {{- $secret = $consumer.existingSecret -}}
{{- else if and (kindIs "map" $default.existingSecret) (default "" $default.existingSecret.name) (default "" $default.existingSecret.key) -}}
  {{- $secret = $default.existingSecret -}}
{{- end -}}
{{- toYaml $secret -}}
{{- end }}

{{/*
Resolve the Redis URL for a given consumer.

Args (dict):
  ctx      - the root context ($)
  consumer - dotted path to the per-consumer Redis block, e.g.
             "dashboard.session.redis"
             "workspaceServices.memoryApi.cache.redis"
             "enterprise.arena.queue.redis"

Resolution order — first non-empty wins:
  1. <consumer>.existingSecret    → returns ""; caller uses
     omnia.redis.urlEnv to emit a secretKeyRef-sourced env entry.
  2. <consumer>.url               → literal URL.
  3. <consumer>.host              → decomposed; synthesise plaintext URL.
  4. redis.default.existingSecret → returns "" (same as 1).
  5. redis.default.url            → literal URL.
  6. redis.default.host           → decomposed; synthesise plaintext URL.
  7. ""                           → consumer disabled.

There is no in-chart Redis arm. charts/omnia-dev runs one for development and
values-dev.yaml points redis.default.host at it, so a dev install resolves
through form 6 like any other.

`omnia.redis.url` returns the literal URL string for forms 2, 3, 5, 6
or empty string for forms 1, 4, 7. To detect the existingSecret form
and emit the correct env entry, use `omnia.redis.hasSecret` and
`omnia.redis.urlEnv` (paired helper).
*/}}
{{- define "omnia.redis.url" -}}
{{- $secret := fromYaml (include "omnia.redis._existingSecret" .) -}}
{{- if and (kindIs "map" $secret) $secret.name -}}
{{- /* secret form — caller renders env via omnia.redis.urlEnv */ -}}
{{- else -}}
{{- $consumer := fromYaml (include "omnia.redis._lookupConsumer" .) -}}
{{- $default := .ctx.Values.redis.default | default dict -}}
{{- if and (kindIs "map" $consumer) $consumer.url -}}
{{- $consumer.url -}}
{{- else if and (kindIs "map" $consumer) $consumer.host -}}
{{- include "omnia.redis.synthesise" $consumer -}}
{{- else if $default.url -}}
{{- $default.url -}}
{{- else if $default.host -}}
{{- include "omnia.redis.synthesise" $default -}}
{{- /*
No in-chart fallback. There used to be one more arm here, synthesising a URL
for a Redis the chart deployed itself — which meant the parent had to know a
resource name it no longer owns. charts/omnia-dev runs that Redis now, and
values-dev.yaml sets `redis.default.host` to its Service, so a dev install
resolves through `$default.host` above like any other install.
*/ -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Returns "true" when the consumer's resolved URL comes from an
existingSecret (rather than a literal URL or decomposed form);
otherwise returns "". Use to branch in templates between literal-value
and secretKeyRef-sourced EnvVar emission.
*/}}
{{- define "omnia.redis.hasSecret" -}}
{{- $secret := fromYaml (include "omnia.redis._existingSecret" .) -}}
{{- if and (kindIs "map" $secret) $secret.name -}}
true
{{- end -}}
{{- end }}

{{/*
Emit a single EnvVar entry carrying the resolved Redis URL.

Args (dict):
  ctx      - the root context ($)
  consumer - dotted path to the per-consumer Redis block.
  envName  - name of the env var to emit, e.g. "OMNIA_SESSION_REDIS_URL".

Produces nothing when the consumer's URL resolves empty (consumer
disabled). Use the alongside `omnia.validate*` helpers to fail render
when an empty URL would silently break the consumer.

Output forms:
  Literal/decomposed/subchart →
    - name: <envName>
      value: "<resolved URL>"

  existingSecret →
    - name: <envName>
      valueFrom:
        secretKeyRef:
          name: "<secret name>"
          key:  "<secret key>"

Pod templates use this in their env: list:

  env:
    {{- include "omnia.redis.urlEnv" (dict "ctx" . "consumer" "..." "envName" "...") | nindent 12 }}
*/}}
{{- define "omnia.redis.urlEnv" -}}
{{- $secret := fromYaml (include "omnia.redis._existingSecret" .) -}}
{{- if and (kindIs "map" $secret) $secret.name -}}
- name: {{ .envName }}
  valueFrom:
    secretKeyRef:
      name: {{ $secret.name | quote }}
      key: {{ $secret.key | quote }}
{{- else -}}
{{- $url := include "omnia.redis.url" . -}}
{{- if $url -}}
- name: {{ .envName }}
  value: {{ $url | quote }}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Synthesise a plaintext Redis URL from a decomposed config block.

Block shape:
  host: required
  port: default 6379
  db:   default 0
  user: default "" (Redis ACL default user)
  tls.caExistingSecret: ignored here (CA is mounted as a file by
    consumer templates; the URL just uses redis:// vs rediss://
    based on the scheme implied by tls).

Output: "redis://[user@]host:port/db".

The decomposed form intentionally cannot synthesise auth (no password
field). Callers wanting auth use the `existingSecret` form instead.
*/}}
{{- define "omnia.redis.synthesise" -}}
{{- $port := default 6379 .port -}}
{{- $db := default 0 .db -}}
{{- $user := default "" .user -}}
{{- if $user -}}
{{- printf "redis://%s@%s:%v/%v" $user .host $port $db -}}
{{- else -}}
{{- printf "redis://%s:%v/%v" .host $port $db -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: managementApi.replicaCount > 1 with no resolved session
Redis means per-pod in-memory sessions. Users get logged out the moment
their request hits a different replica. Fail render rather than ship a
silently broken multi-replica deployment. management-api holds the
sessions; the dashboard is static files and scales freely (#2634).

Included from management-api's Deployment.
*/}}
{{- define "omnia.validateSession" -}}
{{- if (include "omnia.managementApi.enabled" .) -}}
{{- $replicas := int (default 1 .Values.managementApi.replicaCount) -}}
{{- if gt $replicas 1 -}}
{{- $args := dict "ctx" . "consumer" "dashboard.session.redis" -}}
{{- $sessionURL := include "omnia.redis.url" $args -}}
{{- $hasSecret := include "omnia.redis.hasSecret" $args -}}
{{- if and (not $sessionURL) (not $hasSecret) -}}
{{- fail "managementApi.replicaCount > 1 requires a resolvable Redis session store. Set redis.default or dashboard.session.redis (dev: enable charts/omnia-dev and point redis.default.host at it, as values-dev.yaml does), or scale to managementApi.replicaCount=1." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: dashboard.apiKeys.store=postgres requires a Postgres URL
(inline or via existingSecret), and store=file requires a keysSecret.
Include this from every template that renders when dashboard.enabled=true.
*/}}
{{- define "omnia.validateApiKeyStore" -}}
{{- if .Values.dashboard.enabled -}}
{{- $ak := .Values.dashboard.apiKeys -}}
{{- if eq (default "memory" $ak.store) "postgres" -}}
{{- $hasUrl := or $ak.postgresUrl $ak.existingPostgresSecret -}}
{{- $builtin := .Values.dashboard.builtin -}}
{{- $hasBuiltin := and (eq .Values.dashboard.auth.mode "builtin") (or $builtin.postgresUrl $builtin.existingPostgresSecret) -}}
{{- if not (or $hasUrl $hasBuiltin) -}}
{{- fail "dashboard.apiKeys.store=postgres requires dashboard.apiKeys.postgresUrl or dashboard.apiKeys.existingPostgresSecret (or builtin postgres config to fall back to)." -}}
{{- end -}}
{{- end -}}
{{- if eq (default "memory" $ak.store) "file" -}}
{{- if not $ak.keysSecret -}}
{{- fail "dashboard.apiKeys.store=file requires dashboard.apiKeys.keysSecret (the Secret holding keys.json)." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Effective api-key store. A wired postgres secret/URL with the store left at the
"memory" default is almost always a misconfig: in-memory keys are lost on every
management-api restart, silently breaking saved credentials (e.g. deploy-profile
tokens). Promote memory -> postgres when a postgres secret/URL is configured so
a durable backend isn't silently ignored (#1582). Explicit store=file/postgres
is honoured as-is. Used by both the dashboard configmap (OMNIA_AUTH_API_KEYS_STORE,
which management-api reads) and management-api's deployment (postgres URL env)
so they never disagree.
*/}}
{{- define "omnia.dashboard.apiKeyStore" -}}
{{- $ak := .Values.dashboard.apiKeys -}}
{{- $store := default "memory" $ak.store -}}
{{- if and (eq $store "memory") (or $ak.postgresUrl $ak.existingPostgresSecret) -}}
{{- $store = "postgres" -}}
{{- end -}}
{{- $store -}}
{{- end }}

{{/*
Render-time guard: enterprise Arena queue requires durable Redis when
type=redis (which is the default). The in-memory queue mode is only
useful in dev / E2E; production Arena needs jobs to survive controller
restarts.
*/}}
{{- define "omnia.validateArenaQueue" -}}
{{- if and .Values.enterprise.enabled (eq (default "redis" .Values.enterprise.arena.queue.type) "redis") -}}
{{- $args := dict "ctx" . "consumer" "enterprise.arena.queue.redis" -}}
{{- $arenaURL := include "omnia.redis.url" $args -}}
{{- $hasSecret := include "omnia.redis.hasSecret" $args -}}
{{- if and (not $arenaURL) (not $hasSecret) -}}
{{- fail "enterprise.arena.queue.type=redis requires a resolvable Redis URL. Set redis.default or enterprise.arena.queue.redis (dev: enable charts/omnia-dev and point redis.default.host at it, as values-dev-enterprise.yaml does), or set enterprise.arena.queue.type=memory (dev only)." -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render-time guard: the CRDs are a SEPARATE release (charts/omnia-crds).

Both available primitives fail the same way off-cluster — `lookup` returns empty
under `helm template` and `--dry-run`, and .Capabilities.APIVersions holds only
the built-in list — so a naive check cannot tell "CRD absent" from "no cluster to
ask", and would fire on every render including the GCP marketplace deployer's.
kube-system is the liveness probe: it exists on every cluster and nowhere else.

The assertion is >=, not ==. CRDs must always roll forward ahead of the app, so a
staggered upgrade (crds first, app second) is the CORRECT order and equality
would reject it.

An absent chart-version annotation FAILS render — it does not skip the check.
The design this superseded treated it as a grace period lasting "until the CRD
chart's first upgrade", but that upgrade never arrives for an operator who runs
`helm upgrade omnia` against CRDs adopted from a pre-omnia-crds install and
never once installs the omnia-crds release: `lookup` finds the kinds (adopted
CRDs keep serving), the annotation is absent so the old code skipped the
version check, and the upgrade silently succeeds — new operator code running
forever against beta.17-shaped CRD schemas, on a cluster that will never
upgrade again because nothing ever told it to. Failing here instead names the
two recovery commands below, and every workflow that installs this chart
against a live cluster installs omnia-crds from the chart first (which stamps
the annotation on every kind), so this is not a new liveness dependency for
CI — only for a genuinely pre-split cluster, which is exactly the case this
must catch.
*/}}
{{- define "omnia.validateCrds" -}}
{{- if .Values.crdPreflight.enabled -}}
{{- $live := lookup "v1" "Namespace" "" "kube-system" -}}
{{- if $live -}}
{{- /* Discovery lags a fresh CRD until it is Established and the client's
cache refreshes, so .Capabilities alone fails `helm install omnia` run straight
after `helm install omnia-crds` and passes the identical rerun seconds later
(#3476). A CRD object that exists is installed; ask for it directly before
failing. */ -}}
{{- $crd := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "agentruntimes.omnia.altairalabs.ai" -}}
{{- if not (or $crd (.Capabilities.APIVersions.Has "omnia.altairalabs.ai/v1alpha1/AgentRuntime")) -}}
{{- fail (printf "Omnia CRDs are not installed. They ship as their own release since 0.9.0-beta.19:\n\n  helm install omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s\n\nUpgrading an install that predates that chart? The CRDs already in your cluster carry no Helm ownership metadata, so run hack/adopt-crds.sh --release-namespace %s first.\n\nIf the identity running this install cannot get namespaces, set crdPreflight.enabled=false." .Chart.Version .Release.Namespace .Release.Namespace) -}}
{{- end -}}
{{- $arenaCrd := dict -}}
{{- if .Values.enterprise.enabled -}}
{{- $arenaCrd = lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "arenaruns.omnia.altairalabs.ai" -}}
{{- end -}}
{{- if and .Values.enterprise.enabled (not (or $arenaCrd (.Capabilities.APIVersions.Has "omnia.altairalabs.ai/v1alpha1/ArenaRun"))) -}}
{{- fail (printf "enterprise.enabled=true, but omnia-crds was installed with enterprise.enabled=false, so the enterprise kinds are missing (Arena, ToolPolicy, RolloutAnalysis, SessionPrivacyPolicy, PromptPackSource). Flipping enterprise.enabled here does not create them — they are a separate release's business:\n\n  helm upgrade omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s --set enterprise.enabled=true\n" .Chart.Version .Release.Namespace) -}}
{{- end -}}
{{- $v := "" -}}
{{- if $crd -}}
{{- $v = dig "metadata" "annotations" "omnia.altairalabs.ai/chart-version" "" $crd -}}
{{- end -}}
{{- if not $v -}}
{{- fail (printf "Omnia CRDs are installed, but carry no omnia.altairalabs.ai/chart-version annotation — these kinds exist but no omnia-crds RELEASE owns them, which means this is a pre-split cluster (CRDs from the old crds/ mechanism, or adopted ownership metadata without ever installing the chart). Adopt them, then install the release:\n\n  hack/adopt-crds.sh --context <ctx> --release-namespace %s\n  helm install omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s\n\nIf the identity running this install cannot get namespaces, set crdPreflight.enabled=false." .Release.Namespace .Chart.Version .Release.Namespace) -}}
{{- end -}}
{{- if not (semverCompare (printf ">=%s" .Chart.Version) $v) -}}
{{- fail (printf "omnia-crds is at %s, older than this chart at %s. CRDs roll forward FIRST:\n\n  helm upgrade omnia-crds oci://ghcr.io/altairalabs/charts/omnia-crds --version %s -n %s\n" $v .Chart.Version .Chart.Version .Release.Namespace) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Resolve OTLP tracing endpoint for runtime/facade containers.
Priority:
1. .Values.tracing.endpoint (explicit override)
2. Alloy service (when alloy.enabled=true)
3. Tempo service (when tempo.enabled=true)
Returns empty string when no endpoint can be resolved.
*/}}
{{- define "omnia.tracing.endpoint" -}}
{{- if .Values.tracing.endpoint -}}
{{- .Values.tracing.endpoint -}}
{{- else if .Values.alloy.enabled -}}
{{- printf "%s-alloy:4317" .Release.Name -}}
{{- else if .Values.tempo.enabled -}}
{{- printf "%s-tempo:4317" .Release.Name -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end }}

{{/*
The install-wide defaults for the workspace content PVC, passed identically to
every process that can create it: arena-controller (a project, a run, a project
PromptPackSource) and the operator (a SandboxClaim). One helper, so the PVC is
the same whoever creates it first.

The platform-wide class (workspaces.storage.storageClass) is authoritative and
independent of the in-cluster NFS CSI driver; the NFS-CSI-derived class is only
a fallback when none is set (local-dev NFS, #1322). A Workspace's own
spec.storage still wins over all three.
*/}}
{{- define "omnia.workspaceStorageArgs" -}}
{{- if .Values.workspaces.storage.storageClass }}
- --workspace-storage-class={{ .Values.workspaces.storage.storageClass }}
{{- else if and .Values.nfs.csiDriver.enabled .Values.nfs.external.server }}
- --workspace-storage-class={{ include "omnia.nfsStorageClass" . }}
{{- end }}
{{- with .Values.workspaces.storage.size }}
- --workspace-storage-size={{ . }}
{{- end }}
{{- with .Values.workspaces.storage.accessModes }}
- --workspace-storage-access-modes={{ join "," . }}
{{- end }}
{{- end }}

{{/*
The licence API management-api reads (OPERATOR_API_URL, in the dashboard
ConfigMap and its own env, #2630): dashboard.operatorApiUrl when set, else arena-controller's, which holds
the only licence validator — and nothing without Enterprise.
*/}}
{{- define "omnia.operatorApiUrl" -}}
{{- if .Values.dashboard.operatorApiUrl -}}
{{- .Values.dashboard.operatorApiUrl -}}
{{- else if .Values.enterprise.enabled -}}
http://{{ include "omnia.fullname" . }}-arena-controller:{{ ((.Values.enterprise.arena.controller).api).port | default 8082 }}
{{- end -}}
{{- end }}

{{/*
Whether management-api serves the management-plane keys (JWKS and
service-token mint) to their consumers: managementApi.servesManagementPlaneKeys
(on by default) and management-api deployed. "true" or "".
*/}}
{{- define "omnia.managementApi.servesKeys" -}}
{{- if and .Values.managementApi.servesManagementPlaneKeys (include "omnia.managementApi.enabled" .) -}}true{{- end -}}
{{- end }}

{{/*
Namespace of the KEDA HTTP add-on (#1117): this release's namespace when the
chart bundles it, otherwise kedaHttpAddOn.namespace.
*/}}
{{- define "omnia.kedaHttpAddOnNamespace" -}}
{{- if (index .Values "keda-add-ons-http").enabled -}}
{{- .Release.Namespace -}}
{{- else -}}
{{- .Values.kedaHttpAddOn.namespace | default "keda" -}}
{{- end -}}
{{- end -}}

{{/*
arena-controller's API as a pod in any namespace reaches it: the licence API,
the template API, and the Dreaming tools (#2511).
*/}}
{{- define "omnia.arenaController.apiURL" -}}
{{- printf "http://%s-arena-controller.%s.svc.cluster.local:%v" (include "omnia.fullname" .) .Release.Namespace (((.Values.enterprise.arena.controller).api).port | default 8082) -}}
{{- end }}

{{/*
arena-controller's ServiceAccount subject, as session-api, memory-api and
privacy-api list their system callers.
*/}}
{{- define "omnia.arenaController.subject" -}}
{{- printf "system:serviceaccount:%s:%s" .Release.Namespace (include "omnia.arenaController.serviceAccountName" .) -}}
{{- end }}

{{/*
A Deployment's affinity: the component's podOverrides.affinity, else the
chart-wide `affinity`, else a preferred anti-affinity that spreads the
component's own replicas across nodes. The fallback selects the labels the
component's pods carry, release included, so each component spreads only
against its own replicas; a single chart-wide default could select only one
component's pods (#3806). The selector keys are spelled out rather than taken
from the selectorLabels helpers because the operator's own selector
(omnia.selectorLabels) has no component label and also matches arena-controller
and PromptKit LSP pods; tests/component-anti-affinity_test.yaml checks each
selector against its pod template's labels, so a renamed label fails there.
Call with dict "root" $ "po" $po "name" <app.kubernetes.io/name> "component" <app.kubernetes.io/component>.
*/}}
{{- define "omnia.podAffinity" -}}
{{- with (.po.affinity | default .root.Values.affinity) }}
{{- toYaml . }}
{{- else }}
podAntiAffinity:
  preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        labelSelector:
          matchExpressions:
            - key: app.kubernetes.io/name
              operator: In
              values:
                - {{ .name }}
            - key: app.kubernetes.io/component
              operator: In
              values:
                - {{ .component }}
            - key: app.kubernetes.io/instance
              operator: In
              values:
                - {{ .root.Release.Name }}
        topologyKey: kubernetes.io/hostname
{{- end }}
{{- end }}
