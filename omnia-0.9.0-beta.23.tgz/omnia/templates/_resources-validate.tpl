{{/*
omnia.validateResources checks the values the operator's omnia-resources
release renders from (charts/omnia-resources). That chart renders inside the
operator, so a mistake caught there surfaces as an Event on the values
ConfigMap, after `helm install` has reported success. Caught here, it fails the
install and names the value to change.

Every check the resources templates would otherwise need lives here, once.
*/}}
{{- define "omnia.validateResources" -}}
{{- $rp := .Values.sessionRetention.defaultPolicy }}
{{- if and $rp.create $rp.coldArchive.enabled (not $rp.coldArchive.retentionDays) }}
{{- fail "sessionRetention.defaultPolicy.coldArchive.retentionDays is required when cold archive is enabled" }}
{{- end }}
{{- if ((.Values.consolidation | default dict).systemPacks | default dict).enabled }}
{{- fail "consolidation.systemPacks has been removed: it installed the safe-default memory consolidation pack, and the consolidation worker that called it went with the legacy memory store. Remove the consolidation block from your values." }}
{{- end }}
{{- $dw := .Values.defaultWorkspace }}
{{- $emb := $dw.embeddingProvider | default dict }}
{{- if and $dw.enabled $emb.type }}
{{- if not $emb.model }}
{{- fail "defaultWorkspace.embeddingProvider.model is required when defaultWorkspace.embeddingProvider.type is set — the Provider CRD refuses a Provider with no model." }}
{{- end }}
{{- if not $emb.secretRef }}
{{- fail "defaultWorkspace.embeddingProvider.secretRef is required when defaultWorkspace.embeddingProvider.type is set — the name of a Secret in the workspace namespace holding the vendor API key (key api-key)." }}
{{- end }}
{{- if $dw.embeddingProviderRef }}
{{- fail (printf "defaultWorkspace.embeddingProviderRef (%q) and defaultWorkspace.embeddingProvider.type (%q) are both set — set one: embeddingProviderRef to bind a Provider you create, or embeddingProvider to have one rendered." $dw.embeddingProviderRef $emb.type) }}
{{- end }}
{{- end }}
{{- $sb := .Values.sandbox }}
{{- if $sb.enabled }}
{{- if hasKey $sb "defaultClass" }}
{{- fail "sandbox.defaultClass has been renamed to sandbox.codegenClass: there is no default sandbox class any more — a ToolRegistry handler's `sandbox.class` names the class its sandboxes are built from, and the chart's codegen-sandbox registry names this one. Move name, resources and runtimeClassName under sandbox.codegenClass." }}
{{- end }}
{{- if not $sb.toolRegistry.namespace }}
{{- fail "sandbox.toolRegistry.namespace is required when sandbox.enabled — the namespace of the AgentRuntime this registry is for. A ToolRegistry an AgentRuntime cannot reference is not worth installing." }}
{{- end }}
{{- if not $sb.codegenClass.name }}
{{- fail "sandbox.codegenClass.name is required when sandbox.enabled — the codegen-sandbox ToolRegistry's handler names this class." }}
{{- end }}
{{- if not $sb.image }}
{{- fail "sandbox.image is required when sandbox.enabled — the ClusterSandboxClass has no other source for the image a claimed sandbox runs." }}
{{- end }}
{{- include "omnia.validateSandboxClass" (dict "c" $sb.codegenClass "path" "sandbox.codegenClass" "why" "the sandbox runs agent-directed code, and an unbounded pod can take the node down. The SandboxClass CRD rejects it too.") }}
{{- end }}
{{- range $runtime, $p := ($sb.runtimePresets | default dict) }}
{{- if $p.enabled }}
{{- if not $sb.enabled }}
{{- fail (printf "sandbox.runtimePresets.%s.enabled needs sandbox.enabled: the preset is a copy of the codegen class, which installs with the sandbox." $runtime) }}
{{- end }}
{{- if not $p.name }}
{{- fail (printf "sandbox.runtimePresets.%s.name is required when the preset is enabled — a ToolRegistry handler's sandbox.class names it." $runtime) }}
{{- end }}
{{- if not $p.runtimeClassName }}
{{- fail (printf "sandbox.runtimePresets.%s.runtimeClassName is required when the preset is enabled — the name of the cluster's %s RuntimeClass (`kubectl get runtimeclass`). It has no default, because installs name it differently." $runtime $runtime) }}
{{- end }}
{{- end }}
{{- end }}
{{- $bg := (($sb.browserClass.runtimePresets | default dict).gvisor) | default dict }}
{{- if $bg.enabled }}
{{- if not (and $sb.enabled $sb.browserClass.enabled) }}
{{- fail "sandbox.browserClass.runtimePresets.gvisor.enabled needs sandbox.enabled and sandbox.browserClass.enabled: the preset is a copy of the browser class, which installs with them." }}
{{- end }}
{{- if not $bg.name }}
{{- fail "sandbox.browserClass.runtimePresets.gvisor.name is required when the preset is enabled — a ToolRegistry handler's sandbox.class names it." }}
{{- end }}
{{- if not $bg.runtimeClassName }}
{{- fail "sandbox.browserClass.runtimePresets.gvisor.runtimeClassName is required when the preset is enabled — the name of the cluster's gVisor RuntimeClass (`kubectl get runtimeclass`). It has no default, because installs name it differently." }}
{{- end }}
{{- end }}
{{- if $sb.enabled }}
{{- $pa := $sb.promptarenaClass }}
{{- if $pa.enabled }}
{{- if not $pa.name }}
{{- fail "sandbox.promptarenaClass.name is required when sandbox.promptarenaClass.enabled — SandboxClaims resolve their class by this name." }}
{{- end }}
{{- if not $pa.image.repository }}
{{- fail "sandbox.promptarenaClass.image.repository is required when sandbox.promptarenaClass.enabled — the ClusterSandboxClass has no other source for the image a claimed sandbox runs." }}
{{- end }}
{{- include "omnia.validateSandboxClass" (dict "c" $pa "path" "sandbox.promptarenaClass" "why" "the sandbox runs agent-directed code, and an unbounded pod can take the node down. The SandboxClass CRD rejects it too.") }}
{{- end }}
{{- $bc := $sb.browserClass }}
{{- if $bc.enabled }}
{{- if not $bc.name }}
{{- fail "sandbox.browserClass.name is required when sandbox.browserClass.enabled — SandboxClaims resolve their class by this name." }}
{{- end }}
{{- if not $bc.image.repository }}
{{- fail "sandbox.browserClass.image.repository is required when sandbox.browserClass.enabled." }}
{{- end }}
{{- include "omnia.validateSandboxClass" (dict "c" $bc "path" "sandbox.browserClass" "why" "the SandboxClass CRD rejects an untrusted class without them.") }}
{{- $ec := $bc.enrolment }}
{{- if $ec.enabled }}
{{- if not $ec.name }}
{{- fail "sandbox.browserClass.enrolment.name is required when the enrolment class is enabled: the operator's --browser-enrolment-class names it." }}
{{- end }}
{{- if not $ec.enrolmentArgs }}
{{- fail "sandbox.browserClass.enrolment.enrolmentArgs must be set: they start the bridge in interactive mode, and an enrolment class without them is refused." }}
{{- end }}
{{- if not $ec.view }}
{{- fail "sandbox.browserClass.enrolment.view is required: it names the port the dashboard's live view reaches." }}
{{- end }}
{{- if not $ec.ports }}
{{- fail "a sandbox class's values must set ports: the ToolRegistry handler addresses one by name, and a class without ports cannot be dialled" }}
{{- end }}
{{- end }}
{{- end }}
{{- $btr := $bc.toolRegistry | default dict }}
{{- if $btr.enabled }}
{{- if not $bc.enabled }}
{{- fail "sandbox.browserClass.toolRegistry.enabled needs sandbox.browserClass.enabled: the registry's sandbox names the browser class, and a registry naming no class serves no tools." }}
{{- end }}
{{- if not $btr.name }}
{{- fail "sandbox.browserClass.toolRegistry.name is required when the browser ToolRegistry is enabled: an AgentRuntime's toolRegistryRef names it." }}
{{- end }}
{{- if not $btr.allowedTools }}
{{- fail "sandbox.browserClass.toolRegistry.allowedTools must list at least one tool: a sandbox handler's allowlist is required, and an empty one offers the model nothing." }}
{{- end }}
{{- end }}
{{- end }}
{{- include "omnia.validateE2BTemplates" . }}
{{- end }}

{{/*
omnia.validateE2BTemplates: sandbox.e2bTemplates (#3602). An Enterprise
capability, so it needs enterprise.enabled; each enabled template needs a name
(its E2B template ID), an image and bounded resources.
*/}}
{{- define "omnia.validateE2BTemplates" -}}
{{- $e2b := .Values.sandbox.e2bTemplates | default dict }}
{{- if $e2b.enabled }}
{{- if not .Values.enterprise.enabled }}
{{- fail "sandbox.e2bTemplates.enabled needs enterprise.enabled: the E2B templates are served by the E2B API and the sandbox gateway, which are Enterprise." }}
{{- end }}
{{- if include "omnia.openshift" . }}
{{- fail "sandbox.e2bTemplates.enabled is not supported with openshift.enabled: the templates' envd runs as uid 65532, the one user its image has, and restricted-v2 assigns every pod a uid of its own." }}
{{- end }}
{{- if and ($e2b.base | default dict).enabled ($e2b.codeInterpreter | default dict).enabled (eq $e2b.base.name $e2b.codeInterpreter.name) }}
{{- fail (printf "sandbox.e2bTemplates.base.name and sandbox.e2bTemplates.codeInterpreter.name are both %q: each is a ClusterSandboxClass, and a template ID names one." $e2b.base.name) }}
{{- end }}
{{- range $key := list "base" "codeInterpreter" }}
{{- $t := get $e2b $key | default dict }}
{{- if $t.enabled }}
{{- if not $t.name }}
{{- fail (printf "sandbox.e2bTemplates.%s.name is required when the template is enabled: it is the E2B template ID the SDKs name." $key) }}
{{- end }}
{{- if not ($t.image | default dict).repository }}
{{- fail (printf "sandbox.e2bTemplates.%s.image.repository is required when the template is enabled." $key) }}
{{- end }}
{{- $lim := (($t.resources | default dict).limits) | default dict }}
{{- if not (and (hasKey $lim "cpu") (hasKey $lim "memory")) }}
{{- fail (printf "sandbox.e2bTemplates.%s.resources.limits must set both cpu and memory: the sandbox runs whatever an API key sends it, and the SandboxClass CRD rejects an untrusted class without them." $key) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
omnia.validateSandboxClass: limits and ports for one class's values block.
Limits are mandatory because the CRD refuses an untrusted class without them,
and its admission error names a CEL expression rather than the value.
*/}}
{{- define "omnia.validateSandboxClass" -}}
{{- $lim := ((.c.resources).limits) | default dict }}
{{- if not (and (hasKey $lim "cpu") (hasKey $lim "memory")) }}
{{- fail (printf "%s.resources.limits must set both cpu and memory: %s" .path .why) }}
{{- end }}
{{- if not .c.ports }}
{{- fail "a sandbox class's values must set ports: the ToolRegistry handler addresses one by name, and a class without ports cannot be dialled" }}
{{- end }}
{{- end }}
